
## 9. Dark native app appearance

- [x] Pocket Budget uses a dark-first palette in the app shell: charcoal background and surfaces, readable light typography, mint availability accents, lavender planning accents, and coral warnings.
- [x] The dark theme is the default in the Expo app and native system interface style; Android and iOS status-bar content remains readable.
- [x] Hero eyebrow, wallet mark, active navigation pill, floating add button, cards, inputs, dividers, and modal surfaces have dark-theme contrast.
- [x] Signed-out startup does not make an unnecessary cloud/auth request; expected background identity failures remain quiet while interactive cloud actions still report real errors.
