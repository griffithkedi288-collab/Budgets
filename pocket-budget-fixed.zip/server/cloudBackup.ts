import { createHash } from "crypto";
import type { Express, Request, Response } from "express";
import { getCloudBackupByOpenId, insertCloudBackup, updateCloudBackup } from "./db";
import { sdk } from "./_core/sdk";

const MAX_BACKUP_BYTES = 10 * 1024 * 1024;

function contentHash(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function metadata(backup: Awaited<ReturnType<typeof getCloudBackupByOpenId>>) {
  if (!backup) return { exists: false as const, revision: 0, updatedAt: null, contentHash: null };
  return {
    exists: true as const,
    revision: backup.revision,
    updatedAt: backup.updatedAt.toISOString(),
    contentHash: backup.contentHash,
  };
}

async function authenticatedUser(req: Request, res: Response) {
  try {
    return await sdk.authenticateRequest(req);
  } catch {
    res.status(401).json({ error: "Sign in to use cloud backup." });
    return null;
  }
}

export function registerCloudBackupRoutes(app: Express) {
  app.get("/api/sync/backup", async (req, res) => {
    const user = await authenticatedUser(req, res);
    if (!user) return;
    try {
      const backup = await getCloudBackupByOpenId(user.openId);
      res.json(metadata(backup));
    } catch {
      res.status(503).json({ error: "Cloud backup is temporarily unavailable." });
    }
  });

  app.get("/api/sync/backup/content", async (req, res) => {
    const user = await authenticatedUser(req, res);
    if (!user) return;
    try {
      const backup = await getCloudBackupByOpenId(user.openId);
      if (!backup) {
        res.status(404).json({ error: "No cloud backup exists yet." });
        return;
      }
      res.json({ ...metadata(backup), backup: backup.encryptedPayload });
    } catch {
      res.status(503).json({ error: "Cloud backup could not be loaded." });
    }
  });

  app.post("/api/sync/backup", async (req, res) => {
    const user = await authenticatedUser(req, res);
    if (!user) return;
    const backupText = typeof req.body?.backup === "string" ? req.body.backup : "";
    const baseRevision = req.body?.baseRevision === undefined || req.body?.baseRevision === null ? null : Number(req.body.baseRevision);
    if (!backupText || Buffer.byteLength(backupText, "utf8") > MAX_BACKUP_BYTES) {
      res.status(400).json({ error: "Backup is missing or too large." });
      return;
    }
    try {
      const parsed = JSON.parse(backupText) as { version?: number; kdf?: string; salt?: string; nonce?: string; ciphertext?: string };
      if (parsed.version !== 1 || parsed.kdf !== "PBKDF2-SHA256" || typeof parsed.salt !== "string" || typeof parsed.nonce !== "string" || typeof parsed.ciphertext !== "string") {
        res.status(400).json({ error: "An end-to-end encrypted backup is required." });
        return;
      }
      const existing = await getCloudBackupByOpenId(user.openId);
      if (existing && baseRevision !== existing.revision) {
        res.status(409).json({ error: "Cloud backup changed on another device.", ...metadata(existing) });
        return;
      }
      const hash = contentHash(backupText);
      const nextRevision = existing ? existing.revision + 1 : 1;
      const encryptedPayload = backupText;
      if (existing) {
        const updated = await updateCloudBackup(existing.id, existing.revision, { encryptedPayload, contentHash: hash, revision: nextRevision });
        if (!updated) {
          const current = await getCloudBackupByOpenId(user.openId);
          res.status(409).json({ error: "Cloud backup changed on another device.", ...metadata(current) });
          return;
        }
      } else {
        await insertCloudBackup({ userOpenId: user.openId, encryptedPayload, contentHash: hash, revision: nextRevision });
      }
      const saved = await getCloudBackupByOpenId(user.openId);
      res.json(metadata(saved));
    } catch {
      res.status(503).json({ error: "Cloud backup could not be saved." });
    }
  });
}
