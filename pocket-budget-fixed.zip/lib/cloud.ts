import AsyncStorage from "@react-native-async-storage/async-storage";

export type CloudPreferences = {
  enabled: boolean;
  deviceId: string;
  accountOpenId?: string;
};

const CLOUD_PREFERENCES_KEY = "pocketbudget.cloud.preferences";

function createDeviceId(): string {
  return `device_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 12)}`;
}

export async function loadCloudPreferences(): Promise<CloudPreferences> {
  try {
    const raw = await AsyncStorage.getItem(CLOUD_PREFERENCES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<CloudPreferences>;
      if (typeof parsed.deviceId === "string" && parsed.deviceId.length > 0) {
        return { enabled: parsed.enabled === true, deviceId: parsed.deviceId, accountOpenId: parsed.accountOpenId };
      }
    }
  } catch {
    // Fall through to a fresh local preference record.
  }
  const fresh = { enabled: false, deviceId: createDeviceId() } satisfies CloudPreferences;
  await saveCloudPreferences(fresh);
  return fresh;
}

export async function saveCloudPreferences(preferences: CloudPreferences): Promise<void> {
  await AsyncStorage.setItem(CLOUD_PREFERENCES_KEY, JSON.stringify(preferences));
}
