import AsyncStorage from "@react-native-async-storage/async-storage";

import { createId, monthKey } from "./format";
import { decryptLocalRecord, encryptLocalRecord } from "./local-encryption";
import { keepsPinInAsyncStorage, readSecurePinHash, writeSecurePinHash } from "./secure-pin";
import type { BudgetState, Category } from "./types";

export const STORAGE_KEY = "pocket-budget-state-v1";
export const CURRENT_SCHEMA_VERSION = 1;

export const DEFAULT_CATEGORIES: Category[] = [
  { id: "housing", name: "Housing", color: "#D48A78", kind: "budget", archived: false, planned: 0 },
  { id: "food", name: "Food", color: "#A7B4C2", kind: "budget", archived: false, planned: 0 },
  { id: "transport", name: "Transport", color: "#8BAAC7", kind: "budget", archived: false, planned: 0 },
  { id: "giving", name: "Giving", color: "#B59AD8", kind: "budget", archived: false, planned: 0 },
  { id: "personal", name: "Personal", color: "#79B9A6", kind: "budget", archived: false, planned: 0 },
];

export function createDefaultState(month = monthKey(new Date())): BudgetState {
  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    transactions: [],
    categories: DEFAULT_CATEGORIES.map((category) => ({ ...category })),
    budgets: DEFAULT_CATEGORIES.map((category) => ({ month, categoryId: category.id, amount: 0 })),
    bills: [],
    pinHash: null,
  };
}

export function ensureMonthBudgets(state: BudgetState, month: string): BudgetState {
  const known = new Set(state.budgets.filter((budget) => budget.month === month).map((budget) => budget.categoryId));
  const additions = state.categories
    .filter((category) => category.kind === "budget" && !known.has(category.id))
    .map((category) => ({ month, categoryId: category.id, amount: category.planned ?? 0 }));
  return additions.length ? { ...state, budgets: [...state.budgets, ...additions] } : state;
}

function migrateV0ToV1(input: Partial<BudgetState>): BudgetState {
  const base = createDefaultState();
  const categories = Array.isArray(input.categories) && input.categories.length ? input.categories : base.categories;
  const state: BudgetState = {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    transactions: Array.isArray(input.transactions) ? input.transactions : [],
    categories: categories.map((category) => ({
      ...category,
      archived: Boolean(category.archived),
      kind: category.kind ?? "budget",
      color: category.color === "#E6B76C" ? "#A7B4C2" : category.color ?? "#BDE9D9",
    })) as Category[],
    budgets: (Array.isArray(input.budgets) ? input.budgets : base.budgets).filter((budget) => categories.some((category) => category.id === budget.categoryId && (category.kind ?? "budget") === "budget" && !category.archived)),
    bills: Array.isArray(input.bills) ? input.bills : [],
    pinHash: typeof input.pinHash === "string" ? input.pinHash : null,
  };
  return ensureMonthBudgets(state, monthKey(new Date()));
}

function migrate(input: Partial<BudgetState>): BudgetState {
  const version = typeof input.schemaVersion === "number" ? input.schemaVersion : 0;
  if (version <= 0) return migrateV0ToV1(input);
  if (version === CURRENT_SCHEMA_VERSION) return migrateV0ToV1(input);
  // Future versions are normalized through the latest known shape so a newer
  // backup still has a safe, readable fallback instead of crashing on launch.
  return migrateV0ToV1(input);
}

export async function loadState(): Promise<BudgetState> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const securePin = await readSecurePinHash();
      return { ...createDefaultState(), pinHash: securePin };
    }
    const migrated = migrate(JSON.parse(await decryptLocalRecord(raw)) as Partial<BudgetState>);
    const securePin = await readSecurePinHash();
    if (!securePin && migrated.pinHash) await writeSecurePinHash(migrated.pinHash);
    return { ...migrated, pinHash: securePin ?? migrated.pinHash };
  } catch {
    return createDefaultState();
  }
}

export async function saveState(state: BudgetState): Promise<void> {
  await writeSecurePinHash(state.pinHash);
  const localState = keepsPinInAsyncStorage ? state : { ...state, pinHash: null };
  const serialized = JSON.stringify({ ...localState, schemaVersion: CURRENT_SCHEMA_VERSION });
  await AsyncStorage.setItem(STORAGE_KEY, await encryptLocalRecord(serialized));
}

export function exportBackup(state: BudgetState): string {
  const { pinHash: _privatePinHash, ...portableState } = state;
  return JSON.stringify({ ...portableState, schemaVersion: CURRENT_SCHEMA_VERSION }, null, 2);
}

export function exportCloudBackup(state: BudgetState): string {
  const { pinHash: _privatePinHash, ...portableState } = state;
  return JSON.stringify({ ...portableState, schemaVersion: CURRENT_SCHEMA_VERSION });
}

export function importBackup(raw: string): BudgetState {
  const parsed = JSON.parse(raw) as Partial<BudgetState>;
  if (!parsed || typeof parsed !== "object") throw new Error("That backup is not valid JSON.");
  return migrate(parsed);
}

export function hashPin(pin: string): string {
  let hash = 2166136261;
  for (let index = 0; index < pin.length; index += 1) {
    hash ^= pin.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `pb1-${(hash >>> 0).toString(16)}`;
}

export function makeBillId(): string {
  return createId("bill");
}
