# Pocket Budget Android APK handoff

Pocket Budget is configured with an internal `preview` EAS profile that emits an installable Android APK through `android.buildType: "apk"` in `eas.json`.

From the project root, run:

```bash
eas build -p android --profile preview
```

Expo’s current APK guidance documents `android.buildType: "apk"` and the same `eas build -p android --profile preview` command for creating an APK that can be installed directly on an Android device. See the [Expo APK guide](https://docs.expo.dev/build-reference/apk/) and the [EAS Build overview](https://docs.expo.dev/build/introduction/).

When the cloud build finishes, use the APK URL from the EAS build details page or CLI output. Opening that URL on the Android phone downloads the APK for installation. EAS can manage Android signing credentials for the build.

The accepted managed source checkpoint is `85f6570` (`Build Pocket Budget offline UGX ledger`). The mobile project intentionally is not built with native Android tooling inside the resident sandbox; the Dashboard/EAS cloud build is the supported final step for the installable binary.
