# Pocket Budget cloud and transaction research

## Current implementation direction

Pocket Budget will remain local-first: the AsyncStorage ledger is authoritative on the device, while cloud storage is an optional end-to-end encrypted backup/sync layer. The client encrypts snapshots with a user-created recovery passphrase using PBKDF2-SHA256 and AES-GCM; the server stores only the ciphertext envelope and cannot decrypt it. New local entries should remain usable offline and cloud uploads should never block ledger writes.

## Official platform references

- [Google Play SMS and Call Log policy](https://support.google.com/googleplay/android-developer/answer/10208820): SMS and Call Log permissions are high-risk and restricted to permitted core use cases; apps that do not qualify must remove them.
- [Android NotificationListenerService](https://developer.android.com/reference/android/service/notification/NotificationListenerService): notification access is a user-enabled system service that receives posted notifications and must be treated as sensitive.
- [MTN MoMo Developer Portal](https://momodeveloper.mtn.com/): official products include payment status, account balance, notifications, transfers, and get-paid/pay capabilities, subject to business onboarding.
- [Airtel Money Uganda / UNCDF open API announcement](https://www.uncdf.org/article/8241/airtel-money-and-uncdf-launch-open-apis-to-support-innovators-accelerate-digital-financial-inclusion): Airtel Money Uganda announced third-party open APIs, subject to provider access and approval.
- [Standard Bank API Uganda](https://developer.standardbank.com/APIMarketplace/s/api-uganda): the API marketplace lists an Account Enquiry product that can verify account details and retrieve recent transactions for a defined period.

## Safety decisions

The app should not request mobile-money PINs, bank-card PINs, OTPs, or payment authority. Any provider connection should be read-only, use official OAuth/API approval, deduplicate by provider reference, and place imported transactions in a review queue before adding them to the ledger. SMS/notification parsing should be an explicit share/import fallback rather than broad background reading.
