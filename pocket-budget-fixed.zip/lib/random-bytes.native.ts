import * as Crypto from "expo-crypto";

export async function secureRandomBytes(length: number): Promise<Uint8Array> {
  return Crypto.getRandomBytesAsync(length);
}
