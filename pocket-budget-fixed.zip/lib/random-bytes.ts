import { randomBytes } from "@noble/ciphers/utils.js";

export async function secureRandomBytes(length: number): Promise<Uint8Array> {
  return randomBytes(length);
}
