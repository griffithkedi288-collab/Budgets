export const keepsPinInAsyncStorage = true;

export async function readSecurePinHash(): Promise<string | null> {
  return null;
}

export async function writeSecurePinHash(_pinHash: string | null): Promise<void> {
  // Web keeps the verifier with the local AsyncStorage fallback.
}
