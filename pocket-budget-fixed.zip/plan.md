# Pocket Budget — implementation plan

## Product approach

Pocket Budget is a calm, offline-first UGX ledger for one person. The app keeps the fixed Expo Router / React Native / TypeScript starter and stores the complete budget state in AsyncStorage. Cloud backup is optional: the local ledger remains authoritative, while authenticated users can opt into encrypted, revisioned server snapshots and debounced background uploads. There is no bank or mobile-money connection in this phase. Every derived balance is calculated from the transaction ledger rather than stored, which keeps the app auditable and makes backup/restore predictable.

The main screen remains `app/(tabs)/index.tsx`. The domain layer lives in `lib/`: typed models, UGX formatting, versioned persistence and ledger calculations. The screen owns presentation state and calls small ledger operations to add income, expenses, transfers, savings repayments, budget plans, goals, and bills.

## Build scope

- Overview, Transactions, Budgets, Savings, and Goals views inside the existing tab route.
- Month navigation with a current-month shortcut and month-specific summaries.
- Income, expense, transfer, save-today, auto-budget, goal funding, emergency spend, savings repayment, and bill payment flows.
- Budget planning, progress, category creation, safe deletion, goals with targets, monthly bills with paid/overdue state, and a spending breakdown.
- Search and month grouping for transactions, one-step undo for the most recent transaction, and ledger validation that rejects overspending or same-bucket transfers.
- UGX-only formatting with whole numbers and thousands separators.
- AsyncStorage persistence with schema migration, JSON backup/restore, web CSV import/export, native sharing/fallback messaging, and optional 4–6 digit PIN lock with a stored hash.
- Optional Manus OAuth account connection, client-side end-to-end encrypted per-user cloud backup, revision conflict protection, restore-from-cloud, local device preferences, and a visible sync status. A user-created recovery passphrase never leaves the client; the cloud server stores only ciphertext. Cloud backup never receives PINs, card PINs, OTPs, or payment authority; transaction-provider connectors remain a separate approval-gated phase.
- Native splash handoff uses a short fade-and-lift entrance; modal entry forms use keyboard-aware height/padding behavior so the active fields move above the keyboard and settle back after dismissal.
- On native devices, the PIN verifier is stored in Expo SecureStore and removed from the AsyncStorage ledger record; Web keeps its local fallback. Cloud snapshots use PBKDF2-SHA256 plus AES-GCM with a session-only recovery passphrase; the local ledger remains separate from the cloud encryption boundary.
- Native launcher branding, Expo app configuration, and `eas.json` preview profile configured for a directly installable Android APK.

## Design direction

### Design movement

1. Quiet editorial ledger — 0.06
2. Soft neo-brutalist finance tool — 0.04
3. Warm utilitarian notebook — 0.02

Chosen direction: **Quiet editorial ledger**.

### Core principles

- Calm before clever: generous spacing, short labels, and reassuring copy keep money management low-stress.
- Ledger clarity: amounts, sources, destinations, and progress are explicit at the point of action.
- One-thumb flow: segmented tabs, large tap targets, bottom-aligned actions, and short forms work in portrait mode.
- Gentle momentum: progress bars, small completion states, and clear empty states reward consistency without gamification.

### Color philosophy

The palette uses deep ink for trustworthy summaries, soft cream for the canvas, mint for money that is available or settled, lavender for planning, and coral only for warnings or owed-back money. These colors are deliberately low-saturation so the app feels like a useful paper ledger rather than a trading terminal.

Signature brand color: **Ledger mint `#BDE9D9`**.

### Layout paradigm

A vertically flowing ledger page anchors the user in the selected month. A compact identity header leads into a dark hero summary, a single hint, and horizontal view tabs. Each view then uses stacked editorial cards rather than a dense grid. The floating plus button is the only persistent creation affordance.

### Signature elements

- The wallet-square mark paired with the eyebrow “YOUR CALM LEDGER”.
- Dark “BREATHING ROOM” hero card with a large available amount and three quiet metrics.
- Small capsule labels for current month, paid status, and ledger source/destination.

### Interaction and animation

Cards lift by 1–2 px on press with a short opacity change. Modal forms open from the bottom on native and as a centered sheet on web. Progress bars animate from 0 to the current ratio after a plan or transfer changes. Destructive actions use a controlled confirmation sheet instead of relying on native-only alert behavior.

### Typography system

Use the system sans family for reliable native rendering. Eyebrows are uppercase, letter-spaced, and small. Page title and hero amount use a bold display scale. Supporting copy stays at 13–15 px with relaxed line height. All money uses a tabular-feeling bold weight and never uses decimals.

### Brand essence and voice

Pocket Budget is a calm personal ledger for people who want to know what is safe to spend, not just what is in their account. Personality: grounded, clear, encouraging.

Headlines are short and concrete. CTAs are verbs. Example microcopy: “Give every shilling a place.” and “You have room to breathe.”

### Wordmark and logo

The launcher mark is a rounded wallet square with a small mint ledger tab and a cream “P” cutout. It is designed as a distinct square icon without baked-in rounded corners so Android can apply its own mask.

## Project structure

- `app/(tabs)/index.tsx`: app shell, responsive layout, tabs, modals, and interaction flows.
- `app/(tabs)/_layout.tsx`: single hidden-header tab entry for the dashboard.
- `lib/types.ts`: persisted domain models and bucket types.
- `lib/format.ts`: UGX, date, month, and CSV formatting helpers.
- `lib/storage.ts`: AsyncStorage key, defaults, schema migration, backup JSON, and PIN hash helper.
- `lib/ledger.ts`: balance, month totals, budget progress, owed-back, bill status, and transaction validation.
- `lib/cloud.ts` and `lib/_core/api.ts`: local cloud preference state plus authenticated backup/restore calls.
- `lib/e2e.ts` and `lib/random-bytes*.ts`: client-side PBKDF2/AES-GCM cloud encryption and platform random bytes.
- `server/cloudBackup.ts`, `server/db.ts`, and `drizzle/schema.ts`: opaque per-user ciphertext storage, revision conflict checks, and additive managed-database storage.
- `assets/images/*`: Pocket Budget launcher, adaptive icon, splash, favicon, and monochrome assets.
- `app.config.ts` and `eas.json`: Android identity, icon references, version, and APK preview build profile.

## Build workflow

The app is developed and validated in the managed Expo preview on port 8081. TypeScript diagnostics are host-managed. The accepted project checkpoint is the source of truth for the eventual Dashboard/EAS build. The APK path is the Expo-supported preview profile with `android.buildType: "apk"`, equivalent to `eas build -p android --profile preview`; EAS handles the cloud native build and signing.
