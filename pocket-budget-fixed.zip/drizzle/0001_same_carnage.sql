CREATE TABLE `cloudBackups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userOpenId` varchar(64) NOT NULL,
	`encryptedPayload` text NOT NULL,
	`contentHash` varchar(64) NOT NULL,
	`revision` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cloudBackups_id` PRIMARY KEY(`id`),
	CONSTRAINT `cloudBackups_userOpenId_unique` UNIQUE(`userOpenId`)
);
