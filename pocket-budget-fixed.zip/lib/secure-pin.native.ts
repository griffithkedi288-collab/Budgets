import * as SecureStore from "expo-secure-store";

const SECURE_PIN_KEY = "pocket-budget-pin-hash-v1";

export const keepsPinInAsyncStorage = false;

export async function readSecurePinHash(): Promise<string | null> {
  return SecureStore.getItemAsync(SECURE_PIN_KEY);
}

export async function writeSecurePinHash(pinHash: string | null): Promise<void> {
  if (pinHash) await SecureStore.setItemAsync(SECURE_PIN_KEY, pinHash);
  else await SecureStore.deleteItemAsync(SECURE_PIN_KEY);
}
