import { monthKey, safeNumber } from "./format";
import type { Bill, Budget, BucketId, BudgetState, Category, MonthTotals, Transaction } from "./types";

export type LedgerErrorCode = "invalid_amount" | "same_bucket" | "insufficient_balance" | "missing_source";

export class LedgerError extends Error {
  code: LedgerErrorCode;
  constructor(code: LedgerErrorCode, message: string) {
    super(message);
    this.code = code;
  }
}

export function bucketBalance(transactions: Transaction[], bucket: BucketId): number {
  return transactions.reduce((balance, transaction) => {
    if (transaction.type === "income") return balance + (transaction.to === bucket ? transaction.amount : 0);
    if (transaction.type === "expense") return balance - (transaction.from === bucket ? transaction.amount : 0);
    return balance + (transaction.to === bucket ? transaction.amount : 0) - (transaction.from === bucket ? transaction.amount : 0);
  }, 0);
}

function activeBudgetIds(state: BudgetState): Set<string> {
  return new Set(state.categories.filter((category) => category.kind === "budget" && !category.archived).map((category) => category.id));
}

export function monthTotals(state: BudgetState, month: string): MonthTotals {
  const transactions = state.transactions.filter((transaction) => monthKey(transaction.date) === month);
  return {
    income: transactions.filter((transaction) => transaction.type === "income").reduce((sum, transaction) => sum + transaction.amount, 0),
    spent: transactions.filter((transaction) => transaction.type === "expense").reduce((sum, transaction) => sum + transaction.amount, 0),
    budget: state.budgets.filter((budget) => budget.month === month && activeBudgetIds(state).has(budget.categoryId)).reduce((sum, budget) => sum + budget.amount, 0),
  };
}

export function categorySpent(state: BudgetState, categoryId: string, month?: string): number {
  return state.transactions
    .filter((transaction) => transaction.type === "expense" && transaction.from === categoryId && (!month || monthKey(transaction.date) === month))
    .reduce((sum, transaction) => sum + transaction.amount, 0);
}

export function categoryBalance(state: BudgetState, categoryId: string): number {
  return bucketBalance(state.transactions, categoryId);
}

export function budgetFor(state: BudgetState, categoryId: string, month: string): Budget {
  return state.budgets.find((budget) => budget.categoryId === categoryId && budget.month === month) ?? { month, categoryId, amount: 0 };
}

export function progress(spent: number, planned: number): number {
  if (planned <= 0) return 0;
  return Math.min(1, Math.max(0, spent / planned));
}

export function owedBack(transactions: Transaction[]): number {
  const emergencySpends = transactions
    .filter((transaction) => transaction.type === "expense" && transaction.from === "savings" && transaction.note?.startsWith("Emergency spend"))
    .reduce((sum, transaction) => sum + transaction.amount, 0);
  const repayments = transactions
    .filter((transaction) => transaction.type === "transfer" && transaction.to === "savings" && transaction.repayment)
    .reduce((sum, transaction) => sum + transaction.amount, 0);
  return Math.max(0, emergencySpends - repayments);
}

function dueDateForMonth(month: string, dueDay: number): Date {
  const [year, monthNumber] = month.split("-").map(Number);
  const lastDay = new Date(year, monthNumber, 0).getDate();
  return new Date(year, monthNumber - 1, Math.min(Math.max(1, dueDay), lastDay));
}

export function isBillPaid(state: BudgetState, bill: Bill, month: string): boolean {
  return state.transactions.some((transaction) => transaction.type === "expense" && transaction.billId === bill.id && monthKey(transaction.date) === month);
}

export function isBillOverdue(state: BudgetState, bill: Bill, month: string, today = new Date()): boolean {
  if (isBillPaid(state, bill, month)) return false;
  const dueDate = dueDateForMonth(month, bill.dueDay);
  const todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return todayDate.getTime() > dueDate.getTime();
}

export function unpaidBillsTotal(state: BudgetState, month: string, today = new Date()): number {
  return state.bills
    .filter((bill) => !isBillPaid(state, bill, month))
    .reduce((sum, bill) => sum + bill.amount, 0);
}

export function validateTransaction(transactions: Transaction[], transaction: Transaction): void {
  if (!Number.isFinite(transaction.amount) || transaction.amount <= 0) {
    throw new LedgerError("invalid_amount", "Enter an amount greater than UGX 0.");
  }
  if ((transaction.type === "expense" || transaction.type === "transfer") && !transaction.from) {
    throw new LedgerError("missing_source", "Choose where this money is coming from.");
  }
  if (transaction.type === "income" && !transaction.to) {
    throw new LedgerError("missing_source", "Income needs a destination bucket.");
  }
  if (transaction.type === "transfer" && !transaction.to) {
    throw new LedgerError("missing_source", "Choose where this transfer is going.");
  }
  if (transaction.type === "transfer" && transaction.from === transaction.to) {
    throw new LedgerError("same_bucket", "Money needs a different destination.");
  }
  if ((transaction.type === "expense" || transaction.type === "transfer") && transaction.from) {
    const balance = bucketBalance(transactions, transaction.from);
    if (transaction.amount > balance) {
      throw new LedgerError("insufficient_balance", `That would spend more than the ${transaction.from === "free" ? "unbudgeted" : "available"} balance.`);
    }
  }
}

export function autoBudgetShares(state: BudgetState, month: string): Array<{ category: Category; amount: number }> {
  const available = Math.max(0, bucketBalance(state.transactions, "free"));
  const plans = state.categories
    .filter((category) => category.kind === "budget" && !category.archived)
    .map((category) => ({ category, planned: Math.max(0, budgetFor(state, category.id, month).amount) }))
    .filter((item) => item.planned > 0);
  const totalPlanned = plans.reduce((sum, item) => sum + item.planned, 0);
  if (!available || !totalPlanned) return [];
  let assigned = 0;
  return plans.map((item, index) => {
    const amount = index === plans.length - 1 ? available - assigned : Math.floor((available * item.planned) / totalPlanned);
    assigned += amount;
    return { category: item.category, amount: safeNumber(amount) };
  });
}
