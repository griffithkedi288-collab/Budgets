export type TransactionType = "income" | "expense" | "transfer";
export type CategoryKind = "budget" | "goal" | "income";
export type BucketId = "free" | "savings" | string;

export type Transaction = {
  id: string;
  type: TransactionType;
  amount: number;
  date: string;
  from?: BucketId;
  to?: BucketId;
  categoryId?: string;
  note?: string;
  createdAt: string;
  repayment?: boolean;
  billId?: string;
};

export type Category = {
  id: string;
  name: string;
  color: string;
  kind: CategoryKind;
  archived: boolean;
  planned?: number;
  target?: number;
};

export type Budget = {
  month: string;
  categoryId: string;
  amount: number;
};

export type Bill = {
  id: string;
  name: string;
  amount: number;
  sourceId: string;
  dueDay: number;
};

export type BudgetState = {
  schemaVersion: number;
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  bills: Bill[];
  pinHash: string | null;
};

export type MonthTotals = {
  income: number;
  spent: number;
  budget: number;
};

export const FREE_BUCKET: BucketId = "free";
export const SAVINGS_BUCKET: BucketId = "savings";
