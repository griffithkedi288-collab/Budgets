import { gcm } from "@noble/ciphers/aes.js";
import * as SecureStore from "expo-secure-store";

import { secureRandomBytes } from "./random-bytes";

const LOCAL_KEY = "pocket-budget-ledger-key-v1";

type LocalEnvelope = { version: 1; nonce: string; ciphertext: string };

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(hex: string): Uint8Array {
  if (!/^[0-9a-f]+$/i.test(hex) || hex.length % 2 !== 0) throw new Error("Encrypted ledger is malformed.");
  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < bytes.length; index += 1) bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  return bytes;
}

async function deviceKey(): Promise<Uint8Array> {
  const stored = await SecureStore.getItemAsync(LOCAL_KEY);
  if (stored) return hexToBytes(stored);
  const generated = await secureRandomBytes(32);
  await SecureStore.setItemAsync(LOCAL_KEY, bytesToHex(generated));
  return generated;
}

export async function encryptLocalRecord(plainText: string): Promise<string> {
  const nonce = await secureRandomBytes(12);
  const ciphertext = gcm(await deviceKey(), nonce).encrypt(new TextEncoder().encode(plainText));
  return JSON.stringify({ version: 1, nonce: bytesToHex(nonce), ciphertext: bytesToHex(ciphertext) } satisfies LocalEnvelope);
}

export async function decryptLocalRecord(serialized: string): Promise<string> {
  const parsed = JSON.parse(serialized) as Partial<LocalEnvelope>;
  if (parsed.version !== 1 || typeof parsed.nonce !== "string" || typeof parsed.ciphertext !== "string") return serialized;
  try {
    const plain = gcm(await deviceKey(), hexToBytes(parsed.nonce)).decrypt(hexToBytes(parsed.ciphertext));
    return new TextDecoder().decode(plain);
  } catch {
    throw new Error("The local ledger could not be decrypted on this device.");
  }
}
