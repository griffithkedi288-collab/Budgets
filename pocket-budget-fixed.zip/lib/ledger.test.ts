import { describe, expect, it } from "vitest";

import { autoBudgetShares, bucketBalance, isBillOverdue, isBillPaid, owedBack, validateTransaction } from "./ledger";
import { decryptCloudBackup, encryptCloudBackup } from "./e2e";
import { createDefaultState, exportBackup, exportCloudBackup } from "./storage";
import type { Bill, BudgetState, Transaction } from "./types";

function add(state: BudgetState, transaction: Transaction): BudgetState {
  validateTransaction(state.transactions, transaction);
  return { ...state, transactions: [...state.transactions, transaction] };
}

describe("Pocket Budget ledger", () => {
  it("keeps received money in Not yet budgeted", () => {
    let state = createDefaultState("2026-10");
    state = add(state, { id: "income-1", type: "income", amount: 50_000, date: "2026-10-01", to: "free", createdAt: "2026-10-01T08:00:00Z" });
    state = add(state, { id: "income-2", type: "income", amount: 30_000, date: "2026-10-05", to: "free", createdAt: "2026-10-05T08:00:00Z" });
    expect(bucketBalance(state.transactions, "free")).toBe(80_000);
  });

  it("auto-budgets by planned amounts and uses every shilling", () => {
    const base = createDefaultState("2026-10");
    const state = {
      ...base,
      transactions: [{ id: "income", type: "income", amount: 80_000, date: "2026-10-01", to: "free", createdAt: "2026-10-01T08:00:00Z" } as Transaction],
      budgets: base.budgets.map((budget) => budget.categoryId === "housing" ? { ...budget, amount: 50_000 } : budget.categoryId === "food" ? { ...budget, amount: 30_000 } : budget),
    };
    const shares = autoBudgetShares(state, "2026-10");
    expect(shares.find((share) => share.category.id === "housing")?.amount).toBe(50_000);
    expect(shares.find((share) => share.category.id === "food")?.amount).toBe(30_000);
    expect(shares.reduce((sum, share) => sum + share.amount, 0)).toBe(80_000);
  });

  it("tracks emergency spend and clears owed back through repayment", () => {
    let state = createDefaultState("2026-10");
    state = add(state, { id: "income", type: "income", amount: 10_000, date: "2026-10-01", to: "free", createdAt: "2026-10-01T08:00:00Z" });
    state = add(state, { id: "save", type: "transfer", amount: 10_000, date: "2026-10-01", from: "free", to: "savings", createdAt: "2026-10-01T08:00:00Z" });
    state = add(state, { id: "emergency", type: "expense", amount: 5_000, date: "2026-10-02", from: "savings", note: "Emergency spend — clinic", createdAt: "2026-10-02T08:00:00Z" });
    expect(owedBack(state.transactions)).toBe(5_000);
    state = add(state, { id: "income-repayment", type: "income", amount: 5_000, date: "2026-10-03", to: "free", createdAt: "2026-10-03T07:00:00Z" });
    state = add(state, { id: "repay", type: "transfer", amount: 5_000, date: "2026-10-03", from: "free", to: "savings", repayment: true, createdAt: "2026-10-03T08:00:00Z" });
    expect(owedBack(state.transactions)).toBe(0);
  });

  it("marks a bill paid for its current month", () => {
    let state = createDefaultState("2026-10");
    state = add(state, { id: "income", type: "income", amount: 20_000, date: "2026-10-01", to: "free", createdAt: "2026-10-01T08:00:00Z" });
    const bill: Bill = { id: "rent", name: "Rent", amount: 20_000, sourceId: "free", dueDay: 5 };
    expect(isBillPaid(state, bill, "2026-10")).toBe(false);
    expect(isBillOverdue(state, bill, "2026-10", new Date("2026-10-06T08:00:00Z"))).toBe(true);
    state = add(state, { id: "bill-payment", type: "expense", amount: 20_000, date: "2026-10-05", from: "free", billId: bill.id, note: "Bill: Rent", createdAt: "2026-10-05T08:00:00Z" });
    expect(isBillPaid(state, bill, "2026-10")).toBe(true);
    expect(isBillOverdue(state, bill, "2026-10", new Date("2026-10-06T08:00:00Z"))).toBe(false);
  });

  it("does not include the device PIN verifier in cloud payloads", () => {
    const state = { ...createDefaultState("2026-10"), pinHash: "pb1-private" };
    const payload = JSON.parse(exportCloudBackup(state)) as Record<string, unknown>;
    expect(payload.pinHash).toBeUndefined();
    expect(payload.transactions).toEqual([]);
  });

  it("does not include the device PIN verifier in shareable JSON backups", () => {
    const state = { ...createDefaultState("2026-10"), pinHash: "pb1-private" };
    const payload = JSON.parse(exportBackup(state)) as Record<string, unknown>;
    expect(payload.pinHash).toBeUndefined();
  });

  it("encrypts cloud payloads on the client and rejects the wrong recovery passphrase", async () => {
    const encrypted = await encryptCloudBackup("{\"transactions\":[]}", "correct horse battery staple");
    expect(JSON.parse(encrypted).ciphertext).toBeTruthy();
    expect(decryptCloudBackup(encrypted, "correct horse battery staple")).toBe("{\"transactions\":[]}");
    expect(() => decryptCloudBackup(encrypted, "wrong recovery passphrase")).toThrow(/could not decrypt/i);
  });
});
