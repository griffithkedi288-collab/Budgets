export async function encryptLocalRecord(plainText: string): Promise<string> {
  return plainText;
}

export async function decryptLocalRecord(serialized: string): Promise<string> {
  return serialized;
}
