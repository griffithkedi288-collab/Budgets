import Ionicons from "@expo/vector-icons/Ionicons";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Easing,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import * as OAuth from "@/constants/oauth";
import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";
import { loadCloudPreferences, saveCloudPreferences, type CloudPreferences } from "@/lib/cloud";
import { decryptCloudBackup, encryptCloudBackup } from "@/lib/e2e";
import {
  autoBudgetShares,
  bucketBalance,
  budgetFor,
  categoryBalance,
  categorySpent,
  isBillOverdue,
  isBillPaid,
  LedgerError,
  monthTotals,
  owedBack,
  progress,
  unpaidBillsTotal,
  validateTransaction,
} from "@/lib/ledger";
import {
  createId,
  formatDateLong,
  formatMonthTitle,
  formatUGX,
  isCurrentMonth,
  monthKey,
  safeNumber,
  shiftMonth,
  splitCsvLine,
  todayISO,
  toCsvCell,
} from "@/lib/format";
import {
  createDefaultState,
  ensureMonthBudgets,
  exportBackup,
  exportCloudBackup,
  hashPin,
  importBackup,
  loadState,
  makeBillId,
  saveState,
} from "@/lib/storage";
import type { Bill, BudgetState, BucketId, Category, Transaction } from "@/lib/types";

const COLORS = {
  ink: "#ECF5F0",
  darkInk: "#09110F",
  inkSoft: "#C2D2CA",
  cream: "#0B1211",
  paper: "#17221F",
  mint: "#1E4A3F",
  mintDark: "#8CD4B5",
  lavender: "#2D2942",
  lavenderDark: "#C4B3F2",
  coral: "#E99583",
  slate: "#A7B4C2",
  blue: "#8FB7DE",
  border: "#2A3A35",
  muted: "#91A49C",
  white: "#FFFFFF",
  danger: "#FF857B",
};

type Tab = "overview" | "transactions" | "budgets" | "savings" | "goals";
type ModalType =
  | "received"
  | "spent"
  | "save"
  | "repayment"
  | "plan"
  | "category"
  | "goal"
  | "bill"
  | "auto"
  | "backup"
  | "settings"
  | "pin"
  | "edit"
  | "delete"
  | "move"
  | "pay"
  | null;
type ModalPayload = { categoryId?: string; billId?: string; transactionId?: string; mode?: "export" | "restore" };
type FormState = Record<string, string>;

const TAB_LABELS: Array<{ id: Tab; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { id: "overview", label: "Overview", icon: "sparkles-outline" },
  { id: "transactions", label: "Transactions", icon: "list-outline" },
  { id: "budgets", label: "Budgets", icon: "pie-chart-outline" },
  { id: "savings", label: "Savings", icon: "leaf-outline" },
  { id: "goals", label: "Goals", icon: "flag-outline" },
];

function moneySourceLabel(state: BudgetState, bucket?: BucketId): string {
  if (!bucket || bucket === "free") return "Not yet budgeted";
  if (bucket === "savings") return "Savings";
  return state.categories.find((category) => category.id === bucket)?.name ?? "Category";
}

function transactionLabel(state: BudgetState, transaction: Transaction): string {
  if (transaction.type === "income") return "Money received";
  if (transaction.type === "expense") {
    if (transaction.billId) return state.bills.find((bill) => bill.id === transaction.billId)?.name ?? "Bill paid";
    if (transaction.note?.startsWith("Emergency spend")) return "Emergency spend";
    return transaction.note || moneySourceLabel(state, transaction.from);
  }
  if (transaction.repayment) return "Repay savings";
  return `Moved to ${moneySourceLabel(state, transaction.to)}`;
}

function transactionMeta(state: BudgetState, transaction: Transaction): string {
  if (transaction.type === "income") return "Added to Not yet budgeted";
  if (transaction.type === "expense") return `From ${moneySourceLabel(state, transaction.from)}`;
  return `${moneySourceLabel(state, transaction.from)} → ${moneySourceLabel(state, transaction.to)}`;
}

function formatInputValue(value: string): string {
  return value.replace(/[^0-9]/g, "");
}

export default function HomeScreen() {
  const { width } = useWindowDimensions();
  const [state, setState] = useState<BudgetState | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(monthKey(new Date()));
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [transactionFilter, setTransactionFilter] = useState<"month" | "all">("month");
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<ModalType>(null);
  const [modalPayload, setModalPayload] = useState<ModalPayload>({});
  const [form, setForm] = useState<FormState>({});
  const [backupText, setBackupText] = useState("");
  const [confirmAuto, setConfirmAuto] = useState<Array<{ category: Category; amount: number }>>([]);
  const [notice, setNotice] = useState("");
  const [errorNotice, setErrorNotice] = useState("");
  const [lastTransactionId, setLastTransactionId] = useState<string | null>(null);
  const [unlockPin, setUnlockPin] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [cloudPreferences, setCloudPreferences] = useState<CloudPreferences | null>(null);
  const [cloudUser, setCloudUser] = useState<Auth.User | null>(null);
  const [cloudInfo, setCloudInfo] = useState<Api.CloudBackupInfo | null>(null);
  const [cloudInfoLoaded, setCloudInfoLoaded] = useState(false);
  const [cloudStatus, setCloudStatus] = useState<"signed_out" | "ready" | "syncing" | "synced" | "conflict" | "error">("signed_out");
  const [cloudBusy, setCloudBusy] = useState(false);
  const [e2ePassphrase, setE2ePassphrase] = useState("");
  const cloudUploadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const skipCloudUpload = useRef(false);
  const entrance = useRef(new Animated.Value(0)).current;
  const scrollRef = useRef<ScrollView>(null);
  const tabContentY = useRef(0);
  const billsY = useRef(0);

  useEffect(() => {
    void (async () => {
      const [loaded, preferences, storedUser] = await Promise.all([loadState(), loadCloudPreferences(), Auth.getUserInfo()]);
      let user = storedUser;
      if (Platform.OS === "web" && user) {
        const serverUser = await Api.getMe();
        user = serverUser ? { ...serverUser, lastSignedIn: new Date(serverUser.lastSignedIn) } : null;
      }
      const normalizedPreferences: CloudPreferences = user && preferences.accountOpenId === user.openId
        ? preferences
        : { ...preferences, enabled: false, accountOpenId: user?.openId };
      await saveCloudPreferences(normalizedPreferences);
      setState(loaded);
      setUnlocked(!loaded.pinHash);
      setCloudPreferences(normalizedPreferences);
      setCloudUser(user);
      setCloudStatus(user ? "ready" : "signed_out");
    })();
  }, []);

  useEffect(() => {
    if (state) void saveState(state);
  }, [state]);

  useEffect(() => {
    if (!state) return;
    const ensured = ensureMonthBudgets(state, selectedMonth);
    if (ensured.budgets.length !== state.budgets.length) setState(ensured);
  }, [selectedMonth, state]);

  useEffect(() => {
    if (!notice && !errorNotice) return;
    const timeout = setTimeout(() => {
      setNotice("");
      setErrorNotice("");
    }, 3200);
    return () => clearTimeout(timeout);
  }, [notice, errorNotice]);

  useEffect(() => {
    Animated.timing(entrance, {
      toValue: 1,
      duration: 520,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: Platform.OS !== "web",
    }).start();
  }, [entrance]);

  useEffect(() => {
    if (!cloudUser) {
      setCloudInfo(null);
      setCloudInfoLoaded(false);
      return;
    }
    setCloudInfoLoaded(false);
    void (async () => {
      try {
        const info = await Api.getCloudBackupInfo();
        if (!info) {
          setCloudInfo(null);
          setCloudInfoLoaded(true);
          setCloudStatus("signed_out");
          return;
        }
        setCloudInfo(info);
        setCloudInfoLoaded(true);
        setCloudStatus("ready");
      } catch {
        setCloudStatus("error");
      }
    })();
  }, [cloudUser?.openId]);

  const totals = useMemo(() => (state ? monthTotals(state, selectedMonth) : { income: 0, spent: 0, budget: 0 }), [state, selectedMonth]);
  const freeBalance = state ? bucketBalance(state.transactions, "free") : 0;
  const savingsBalance = state ? bucketBalance(state.transactions, "savings") : 0;
  const owed = state ? owedBack(state.transactions) : 0;
  const unpaidTotal = state ? unpaidBillsTotal(state, selectedMonth) : 0;
  const pageWidth = Math.min(width - 32, 760);

  function updateForm(key: string, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function openModal(next: Exclude<ModalType, null>, payload: ModalPayload = {}) {
    setModalPayload(payload);
    setModal(next);
    if (next === "backup") {
      setBackupText(payload.mode === "export" && state ? exportBackup(state) : "");
      return;
    }
    if (next === "received") setForm({ amount: "", date: todayISO(), note: "" });
    if (next === "spent") {
      const defaultSource = state?.categories.find((category) => category.kind === "budget" && !category.archived)?.id ?? "free";
      setForm({ amount: "", date: todayISO(), source: defaultSource, note: "", emergency: "no" });
    }
    if (next === "save") setForm({ amount: "", date: todayISO(), note: "" });
    if (next === "repayment") setForm({ amount: "", date: todayISO() });
    if (next === "plan") {
      const planned = state && payload.categoryId ? budgetFor(state, payload.categoryId, selectedMonth).amount : 0;
      setForm({ amount: planned ? String(planned) : "", name: state?.categories.find((category) => category.id === payload.categoryId)?.name ?? "" });
    }
    if (next === "move") setForm({ amount: "", date: todayISO(), source: "free", note: "" });
    if (next === "category") setForm({ name: "", planned: "", color: COLORS.mintDark });
    if (next === "goal") setForm({ name: "", target: "", color: COLORS.lavenderDark });
    if (next === "bill") {
      const existingBill = state?.bills.find((entry) => entry.id === payload.billId);
      setForm(existingBill
        ? { name: existingBill.name, amount: String(existingBill.amount), source: existingBill.sourceId, dueDay: String(existingBill.dueDay) }
        : { name: "", amount: "", source: state?.categories.find((category) => category.kind === "budget")?.id ?? "free", dueDay: "1" });
    }
    if (next === "pin") setForm({ pin: "", confirm: "" });
    if (next === "settings") setForm({ recoveryPassphrase: "", recoveryConfirm: "" });
    if ((next === "edit" || next === "delete") && payload.transactionId && state) {
      const transaction = state.transactions.find((entry) => entry.id === payload.transactionId);
      if (transaction && next === "edit") setForm({ amount: String(transaction.amount), date: transaction.date, note: transaction.note ?? "", source: transaction.from ?? "free" });
    }
  }

  function closeModal() {
    setModal(null);
    setModalPayload({});
    setForm({});
    setConfirmAuto([]);
  }

  function showNotice(message: string) {
    setErrorNotice("");
    setNotice(message);
  }

  function showError(message: string) {
    setNotice("");
    setErrorNotice(message);
  }

  async function signInToCloud() {
    try {
      await OAuth.startOAuthLogin();
      closeModal();
      showNotice("Secure sign-in opened. Your ledger stays local until you enable backup.");
    } catch {
      showError("Sign-in is not available right now.");
    }
  }

  async function signOutOfCloud() {
    setCloudBusy(true);
    try {
      await Api.logout();
    } catch {
      // Clear local session state even when the network is offline.
    }
    await Auth.removeSessionToken();
    await Auth.clearUserInfo();
    setE2ePassphrase("");
    if (cloudPreferences) {
      const paused = { ...cloudPreferences, enabled: false, accountOpenId: undefined };
      await saveCloudPreferences(paused);
      setCloudPreferences(paused);
    }
    setCloudUser(null);
    setCloudInfo(null);
    setCloudStatus("signed_out");
    setCloudBusy(false);
    showNotice("Cloud account disconnected. Your local ledger is unchanged.");
  }

  async function backupCloud(snapshot: BudgetState | null = state, announceMissingPassphrase = true) {
    if (!snapshot || !cloudUser || !cloudPreferences || cloudPreferences.accountOpenId !== cloudUser.openId || !cloudPreferences.enabled || !cloudInfoLoaded || cloudBusy) return;
    if (!e2ePassphrase) {
      setCloudStatus("error");
      if (announceMissingPassphrase) showError("Enter your recovery passphrase before cloud backup can run.");
      return;
    }
    setCloudBusy(true);
    setCloudStatus("syncing");
    try {
      const encrypted = await encryptCloudBackup(exportCloudBackup(snapshot), e2ePassphrase);
      const info = await Api.uploadCloudBackup(encrypted, cloudInfo?.revision ?? null);
      setCloudInfo(info);
      setCloudStatus("synced");
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      setCloudStatus(message.includes("changed") ? "conflict" : "error");
    } finally {
      setCloudBusy(false);
    }
  }

  async function restoreCloud() {
    if (!cloudUser) return;
    if (!e2ePassphrase) {
      showError("Enter your recovery passphrase to decrypt this backup.");
      return;
    }
    setCloudBusy(true);
    try {
      const result = await Api.restoreCloudBackup();
      const restored = importBackup(decryptCloudBackup(result.backup, e2ePassphrase));
      skipCloudUpload.current = true;
      setState({ ...restored, pinHash: state?.pinHash ?? null });
      setUnlocked(!(state?.pinHash ?? null));
      setCloudInfo(result);
      setCloudStatus("synced");
      closeModal();
      showNotice("Cloud backup restored to this device.");
    } catch (error) {
      showError(error instanceof Error ? error.message : "Cloud backup could not be restored.");
      setCloudStatus("error");
    } finally {
      setCloudBusy(false);
    }
  }

  async function toggleCloudBackup() {
    if (!cloudPreferences || !cloudUser) return;
    if (!cloudPreferences.enabled && !e2ePassphrase) {
      showError("Set a recovery passphrase before enabling end-to-end cloud backup.");
      return;
    }
    const next = { ...cloudPreferences, enabled: !cloudPreferences.enabled, accountOpenId: cloudUser.openId };
    await saveCloudPreferences(next);
    setCloudPreferences(next);
    if (next.enabled) {
      showNotice("Cloud backup enabled. New local changes will sync when online.");
      void backupCloud();
    } else {
      setCloudStatus("ready");
      showNotice("Cloud backup paused. Your local ledger is unchanged.");
    }
  }

  function setRecoveryPassphrase() {
    const passphrase = form.recoveryPassphrase ?? "";
    if (passphrase.length < 12 || passphrase !== form.recoveryConfirm) {
      showError("Use a matching recovery passphrase of at least 12 characters.");
      return;
    }
    setE2ePassphrase(passphrase);
    showNotice("End-to-end encryption is ready for this session. Keep the passphrase safe.");
  }

  function clearRecoveryPassphrase() {
    setE2ePassphrase("");
    showNotice("The recovery passphrase was cleared from this session.");
  }

  useEffect(() => {
    if (skipCloudUpload.current) {
      skipCloudUpload.current = false;
      return;
    }
    if (!state || !cloudUser || !cloudPreferences || !cloudPreferences.enabled || cloudPreferences.accountOpenId !== cloudUser.openId || !cloudInfoLoaded || !unlocked) return;
    if (cloudUploadTimer.current) clearTimeout(cloudUploadTimer.current);
    cloudUploadTimer.current = setTimeout(() => {
      void backupCloud(state, false);
    }, 1800);
    return () => {
      if (cloudUploadTimer.current) clearTimeout(cloudUploadTimer.current);
    };
  }, [state, cloudPreferences?.enabled, cloudUser?.openId, cloudInfoLoaded, unlocked]);

  function appendTransaction(transaction: Transaction, successMessage = "Saved to your ledger.") {
    if (!state) return;
    try {
      validateTransaction(state.transactions, transaction);
      setState({ ...state, transactions: [...state.transactions, transaction] });
      setLastTransactionId(transaction.id);
      closeModal();
      showNotice(successMessage);
    } catch (error) {
      showError(error instanceof LedgerError ? error.message : "That transaction could not be saved.");
    }
  }

  function editTransaction() {
    if (!state || !modalPayload.transactionId) return;
    const current = state.transactions.find((transaction) => transaction.id === modalPayload.transactionId);
    if (!current) return;
    const updated: Transaction = {
      ...current,
      amount: safeNumber(form.amount ?? ""),
      date: form.date || current.date,
      note: form.note?.trim() || undefined,
      from: current.type === "expense" ? ((form.source || current.from || "free") as BucketId) : current.from,
      categoryId: current.type === "expense" && form.source && form.source !== "free" && form.source !== "savings" ? form.source : current.type === "expense" ? undefined : current.categoryId,
    };
    try {
      validateTransaction(state.transactions.filter((transaction) => transaction.id !== current.id), updated);
      setState({ ...state, transactions: state.transactions.map((transaction) => transaction.id === current.id ? updated : transaction) });
      closeModal();
      showNotice("Entry updated. Your balances have been recalculated.");
    } catch (error) {
      showError(error instanceof LedgerError ? error.message : "That entry could not be updated.");
    }
  }

  function deleteTransaction() {
    if (!state || !modalPayload.transactionId) return;
    const transaction = state.transactions.find((entry) => entry.id === modalPayload.transactionId);
    if (!transaction) return;
    setState({ ...state, transactions: state.transactions.filter((entry) => entry.id !== transaction.id) });
    closeModal();
    showNotice("Entry deleted. Your balances have been recalculated.");
  }

  function handleReceived() {
    const amount = safeNumber(form.amount ?? "");
    appendTransaction({
      id: createId("income"),
      type: "income",
      amount,
      date: form.date || todayISO(),
      to: "free",
      note: form.note?.trim() || "Money received",
      createdAt: new Date().toISOString(),
    });
  }

  function handleSpent() {
    const source = (form.source || "free") as BucketId;
    const isEmergency = source === "savings" && form.emergency === "yes";
    appendTransaction(
      {
        id: createId("expense"),
        type: "expense",
        amount: safeNumber(form.amount ?? ""),
        date: form.date || todayISO(),
        from: source,
        categoryId: source === "free" || source === "savings" ? undefined : source,
        note: isEmergency ? `Emergency spend${form.note?.trim() ? ` — ${form.note.trim()}` : ""}` : form.note?.trim() || undefined,
        createdAt: new Date().toISOString(),
      },
      isEmergency ? "Emergency spend recorded. We’ll keep the owed-back amount visible." : "Expense recorded.",
    );
  }

  function handleSaveToday() {
    const destination = (modalPayload.categoryId || "savings") as BucketId;
    appendTransaction({
      id: createId("save"),
      type: "transfer",
      amount: safeNumber(form.amount ?? ""),
      date: form.date || todayISO(),
      from: "free",
      to: destination,
      categoryId: destination === "savings" ? undefined : destination,
      note: form.note?.trim() || "Save today",
      createdAt: new Date().toISOString(),
    }, destination === "savings" ? "Moved into savings." : `Moved into ${moneySourceLabel(state!, destination)}.`);
  }

  function handleRepayment() {
    const amount = safeNumber(form.amount ?? "");
    if (amount > owed) {
      showError(`Repayment cannot be more than ${formatUGX(owed)} owed back.`);
      return;
    }
    appendTransaction({
      id: createId("repay"),
      type: "transfer",
      amount,
      date: form.date || todayISO(),
      from: "free",
      to: "savings",
      note: "Repay savings",
      repayment: true,
      createdAt: new Date().toISOString(),
    }, "Owed back is updated.");
  }

  function handlePlan() {
    if (!state || !modalPayload.categoryId) return;
    const amount = safeNumber(form.amount ?? "");
    const existing = state.budgets.find((budget) => budget.month === selectedMonth && budget.categoryId === modalPayload.categoryId);
    const budgets = existing
      ? state.budgets.map((budget) => budget === existing ? { ...budget, amount } : budget)
      : [...state.budgets, { month: selectedMonth, categoryId: modalPayload.categoryId, amount }];
    const newName = form.name?.trim();
    const categories = newName ? state.categories.map((category) => category.id === modalPayload.categoryId ? { ...category, name: newName } : category) : state.categories;
    setState({ ...state, categories, budgets });
    closeModal();
    showNotice("Budget updated.");
  }

  function handleCategory() {
    if (!state || !form.name?.trim()) {
      showError("Give your category a name first.");
      return;
    }
    const id = createId("category");
    const category: Category = {
      id,
      name: form.name.trim(),
      color: form.color || COLORS.mintDark,
      kind: "budget",
      archived: false,
      planned: safeNumber(form.planned ?? ""),
    };
    setState({
      ...state,
      categories: [...state.categories, category],
      budgets: [...state.budgets, { month: selectedMonth, categoryId: id, amount: safeNumber(form.planned ?? "") }],
    });
    closeModal();
    showNotice("Category added to this month.");
  }

  function handleGoal() {
    if (!state || !form.name?.trim()) {
      showError("Give your goal a name first.");
      return;
    }
    const category: Category = {
      id: createId("goal"),
      name: form.name.trim(),
      color: form.color || COLORS.lavenderDark,
      kind: "goal",
      archived: false,
      target: safeNumber(form.target ?? ""),
    };
    setState({ ...state, categories: [...state.categories, category] });
    closeModal();
    showNotice("Goal created. You can add money whenever you’re ready.");
  }

  function handleBill() {
    if (!state || !form.name?.trim()) {
      showError("Give your bill a name first.");
      return;
    }
    const dueDay = Math.min(31, Math.max(1, safeNumber(form.dueDay || "1")));
    const bill: Bill = {
      id: makeBillId(),
      name: form.name.trim(),
      amount: safeNumber(form.amount ?? ""),
      sourceId: form.source || "free",
      dueDay,
    };
    if (bill.amount <= 0) {
      showError("Enter the bill amount first.");
      return;
    }
    if (modalPayload.billId) {
      setState({ ...state, bills: state.bills.map((entry) => entry.id === modalPayload.billId ? { ...bill, id: entry.id } : entry) });
      closeModal();
      showNotice("Bill updated.");
      return;
    }
    setState({ ...state, bills: [...state.bills, bill] });
    closeModal();
    showNotice("Monthly bill added.");
  }

  function deleteBill() {
    if (!state || !modalPayload.billId) return;
    setState({ ...state, bills: state.bills.filter((entry) => entry.id !== modalPayload.billId) });
    closeModal();
    showNotice("Bill deleted.");
  }

  function handleMove() {
    if (!state || !modalPayload.categoryId) return;
    appendTransaction({
      id: createId("move"),
      type: "transfer",
      amount: safeNumber(form.amount ?? ""),
      date: form.date || todayISO(),
      from: (form.source || "free") as BucketId,
      to: modalPayload.categoryId,
      categoryId: modalPayload.categoryId,
      note: form.note?.trim() || "Moved money",
      createdAt: new Date().toISOString(),
    }, "Money moved.");
  }

  function handlePayBill(bill: Bill) {
    if (!state) return;
    if (bucketBalance(state.transactions, bill.sourceId) < bill.amount) {
      setForm({ source: bill.sourceId });
      setModalPayload({ billId: bill.id });
      setModal("pay");
      return;
    }
    payBill(bill, bill.sourceId, 0);
  }

  function payBill(bill: Bill, sourceId: string, topUp: number) {
    if (!state) return;
    try {
      let next = state;
      if (topUp > 0) {
        const top: Transaction = { id: createId("topup"), type: "transfer", amount: topUp, date: todayISO(), from: "free", to: sourceId, categoryId: sourceId, note: `Top-up for ${bill.name}`, createdAt: new Date().toISOString() };
        validateTransaction(next.transactions, top);
        next = { ...next, transactions: [...next.transactions, top] };
      }
      const expense: Transaction = { id: createId("bill"), type: "expense", amount: bill.amount, date: todayISO(), from: sourceId, categoryId: sourceId === "free" ? undefined : sourceId, note: `Bill: ${bill.name}`, billId: bill.id, createdAt: new Date().toISOString() };
      validateTransaction(next.transactions, expense);
      next = { ...next, transactions: [...next.transactions, expense] };
      setState(next);
      setLastTransactionId(expense.id);
      closeModal();
      showNotice(`${bill.name} paid.`);
    } catch (error) {
      showError(error instanceof LedgerError ? error.message : "That bill could not be paid.");
    }
  }

  function handleAutoBudget() {
    if (!state) return;
    const shares = autoBudgetShares(state, selectedMonth);
    if (!shares.length) {
      showError(freeBalance <= 0 ? "Add money to Not yet budgeted first." : "Add planned amounts to your budgets first.");
      return;
    }
    setConfirmAuto(shares);
    setModal("auto");
  }

  function confirmAutoBudget() {
    if (!state || !confirmAuto.length) return;
    let nextState = state;
    try {
      confirmAuto.forEach(({ category, amount }) => {
        const transaction: Transaction = {
          id: createId("auto"),
          type: "transfer",
          amount,
          date: todayISO(),
          from: "free",
          to: category.id,
          categoryId: category.id,
          note: "Auto-budget",
          createdAt: new Date().toISOString(),
        };
        validateTransaction(nextState.transactions, transaction);
        nextState = { ...nextState, transactions: [...nextState.transactions, transaction] };
      });
      setState(nextState);
      closeModal();
      showNotice("Your free balance now has a place.");
    } catch (error) {
      showError(error instanceof LedgerError ? error.message : "Auto-budget could not be applied.");
    }
  }

  function deleteCategory(category: Category) {
    if (!state) return;
    if (categoryBalance(state, category.id) !== 0) {
      showError(`${category.name} can only be deleted when its balance is UGX 0.`);
      return;
    }
    setState({
      ...state,
      categories: state.categories.map((item) => item.id === category.id ? { ...item, archived: true } : item),
      budgets: state.budgets.filter((budget) => budget.categoryId !== category.id),
    });
    showNotice(`${category.name} archived.`);
  }

  function undoLast() {
    if (!state || !lastTransactionId) {
      showError("There is nothing to undo yet.");
      return;
    }
    setState({ ...state, transactions: state.transactions.filter((transaction) => transaction.id !== lastTransactionId) });
    setLastTransactionId(null);
    showNotice("Last ledger entry undone.");
  }

  function exportCsv() {
    if (!state) return;
    const header = ["id", "type", "amount", "date", "from", "to", "categoryId", "note", "createdAt", "repayment", "billId"];
    const rows = state.transactions.map((transaction) => header.map((key) => toCsvCell(transaction[key as keyof Transaction])).join(","));
    const csv = [header.join(","), ...rows].join("\n");
    if (Platform.OS === "web") {
      const documentRef = (globalThis as { document?: any }).document;
      if (documentRef) {
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const link = documentRef.createElement("a");
        link.href = url;
        link.download = `pocket-budget-${selectedMonth}.csv`;
        link.click();
        URL.revokeObjectURL(url);
        showNotice("CSV exported.");
      }
    } else {
      void Share.share({ title: "Pocket Budget CSV", message: csv });
    }
  }

  function importCsvFromFile() {
    if (Platform.OS !== "web") {
      showNotice("CSV import is available in Web preview. On Android, use JSON backup restore.");
      return;
    }
    const documentRef = (globalThis as { document?: any }).document;
    if (!documentRef) return;
    const input = documentRef.createElement("input");
    input.type = "file";
    input.accept = ".csv,text/csv";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file || !state) return;
      const text = await file.text();
      const lines = text.split(/\r?\n/).filter(Boolean);
      const headers = lines.shift()?.split(",") ?? [];
      const parsed: Transaction[] = lines.map((line: string) => {
        const values = splitCsvLine(line);
        const row = Object.fromEntries(headers.map((header: string, index: number) => [header, values[index] ?? ""]));
        return {
          id: row.id || createId("csv"),
          type: row.type === "income" || row.type === "expense" || row.type === "transfer" ? row.type : "expense",
          amount: safeNumber(row.amount),
          date: row.date || todayISO(),
          from: row.from || undefined,
          to: row.to || undefined,
          categoryId: row.categoryId || undefined,
          note: row.note || undefined,
          createdAt: row.createdAt || new Date().toISOString(),
          repayment: row.repayment === "true",
          billId: row.billId || undefined,
        } as Transaction;
      }).filter((transaction: Transaction) => transaction.amount > 0);
      let transactions = [...state.transactions];
      let rejected = 0;
      const imported: Transaction[] = [];
      parsed.forEach((transaction) => {
        try {
          validateTransaction(transactions, transaction);
          transactions = [...transactions, transaction];
          imported.push(transaction);
        } catch {
          rejected += 1;
        }
      });
      setState({ ...state, transactions });
      showNotice(`${imported.length} imported${rejected ? ` · ${rejected} skipped as invalid` : ""}.`);
    };
    input.click();
  }

  async function shareBackup() {
    if (!state) return;
    const text = exportBackup(state);
    if (Platform.OS === "web") {
      const documentRef = (globalThis as { document?: any }).document;
      if (documentRef) {
        const blob = new Blob([text], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const link = documentRef.createElement("a");
        link.href = url;
        link.download = "pocket-budget-backup.json";
        link.click();
        URL.revokeObjectURL(url);
        showNotice("Backup downloaded.");
      }
    } else {
      await Share.share({ title: "Pocket Budget backup", message: text });
    }
  }

  function restoreBackup() {
    try {
      const restored = importBackup(backupText);
      setState({ ...restored, pinHash: state?.pinHash ?? null });
      setUnlocked(!(state?.pinHash ?? null));
      closeModal();
      showNotice("Backup restored. Your ledger is back in place.");
    } catch (error) {
      showError(error instanceof Error ? error.message : "That backup could not be restored.");
    }
  }

  function savePin() {
    const pin = form.pin ?? "";
    if (!/^\d{4,6}$/.test(pin) || pin !== form.confirm) {
      showError("Use a matching PIN with 4 to 6 digits.");
      return;
    }
    if (state) setState({ ...state, pinHash: hashPin(pin) });
    closeModal();
    showNotice("PIN lock enabled for this device.");
  }

  function unlock() {
    if (state?.pinHash && hashPin(unlockPin) === state.pinHash) {
      setUnlocked(true);
      setUnlockPin("");
    } else {
      showError("That PIN does not match.");
    }
  }

  function removePin() {
    if (state) setState({ ...state, pinHash: null });
    closeModal();
    showNotice("PIN lock removed.");
  }

  function renderHeader() {
    return (
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.walletMark}><Text style={styles.walletMarkText}>P</Text></View>
          <View>
            <Text style={styles.eyebrow}>YOUR CALM LEDGER</Text>
            <Text style={styles.wordmark}>Pocket Budget</Text>
          </View>
        </View>
        <View style={styles.headerActions}>
          <IconButton icon="arrow-up-outline" label="Export backup" onPress={() => void shareBackup()} />
          <IconButton icon="arrow-down-outline" label="Import backup" onPress={() => openModal("backup", { mode: "restore" })} />
          <IconButton icon="settings-outline" label="Data and safety" onPress={() => openModal("settings")} />
        </View>
      </View>
    );
  }

  function renderMonthSwitcher() {
    return (
      <View style={styles.monthRow}>
        <Pressable style={styles.monthArrow} onPress={() => setSelectedMonth(shiftMonth(selectedMonth, -1))} accessibilityLabel="Previous month">
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </Pressable>
        <View style={styles.monthCenter}>
          <Text style={styles.eyebrow}>CURRENT MONTH</Text>
          <Text style={styles.monthTitle}>{formatMonthTitle(selectedMonth)}</Text>
        </View>
        <Pressable style={styles.monthArrow} onPress={() => setSelectedMonth(shiftMonth(selectedMonth, 1))} accessibilityLabel="Next month">
          <Ionicons name="chevron-forward" size={20} color={COLORS.ink} />
        </Pressable>
        {!isCurrentMonth(selectedMonth) && (
          <Pressable style={styles.todayChip} onPress={() => setSelectedMonth(monthKey(new Date()))}>
            <Text style={styles.todayChipText}>Today</Text>
          </Pressable>
        )}
      </View>
    );
  }

  function renderHero() {
    const room = freeBalance + savingsBalance;
    return (
      <View style={styles.hero}>
        <View style={styles.heroTopLine}>
          <Text style={styles.heroEyebrow}>BREATHING ROOM</Text>
          <View style={styles.heroDot} />
        </View>
        <Text style={styles.heroAmount}>{formatUGX(room)}</Text>
        <Text style={styles.heroSubtitle}>Available across your unbudgeted money and savings.</Text>
        <View style={styles.heroMetrics}>
          <Metric label="Income" value={totals.income} />
          <Metric label="Spent" value={totals.spent} />
          <Metric label="Budget" value={totals.budget} />
        </View>
      </View>
    );
  }

  function reviewBills() {
    setActiveTab("budgets");
    setTimeout(() => scrollRef.current?.scrollTo({ y: Math.max(0, tabContentY.current + billsY.current - 12), animated: true }), 350);
  }

  function renderHint() {
    const hasUnpaid = unpaidTotal > 0;
    return (
      <View style={[styles.hintCard, hasUnpaid && styles.hintCardWarm]}>
        <View style={styles.hintIcon}><Ionicons name={hasUnpaid ? "calendar-outline" : "leaf-outline"} size={18} color={hasUnpaid ? COLORS.coral : COLORS.ink} /></View>
        <View style={styles.hintCopy}>
          <Text style={styles.cardEyebrow}>{hasUnpaid ? "A GENTLE NUDGE" : "A LITTLE ROOM"}</Text>
          <Text style={styles.hintText}>
            {hasUnpaid ? `${formatUGX(unpaidTotal)} in bills is waiting this month.` : freeBalance > 0 ? "Give every shilling a place when you’re ready." : "Your ledger is up to date. Keep going gently."}
          </Text>
        </View>
        {hasUnpaid && <Pressable style={styles.smallAction} onPress={reviewBills}><Text style={styles.smallActionText}>Review</Text></Pressable>}
      </View>
    );
  }

  function renderTabs() {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabScroller}>
        {TAB_LABELS.map((tab) => (
          <Pressable key={tab.id} onPress={() => setActiveTab(tab.id)} style={[styles.tab, activeTab === tab.id && styles.tabActive]}>
            <Ionicons name={tab.icon} size={16} color={activeTab === tab.id ? COLORS.ink : COLORS.muted} />
            <Text style={[styles.tabText, activeTab === tab.id && styles.tabTextActive]}>{tab.label}</Text>
          </Pressable>
        ))}
      </ScrollView>
    );
  }

  function renderOverview() {
    const categories = state?.categories.filter((category) => category.kind === "budget" && !category.archived) ?? [];
    const maxSpent = Math.max(1, ...categories.map((category) => categorySpent(state!, category.id, selectedMonth)));
    const recent = [...(state?.transactions ?? [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 3);
    return (
      <View style={styles.sectionGap}>
        <View style={styles.twoColumn}>
          <MiniCard label="Not yet budgeted" value={freeBalance} tint={COLORS.mint} icon="sparkles-outline" onPress={() => openModal("received")} />
          <MiniCard label="Savings" value={savingsBalance} tint={COLORS.lavender} icon="leaf-outline" onPress={() => setActiveTab("savings")} />
        </View>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>THIS MONTH</Text><Text style={styles.sectionTitle}>Spend by category</Text></View><Text style={styles.sectionMeta}>{formatUGX(totals.spent)} spent</Text></View>
        <View style={styles.card}>
          {categories.length === 0 ? <EmptyState text="Create a category to see your spending shape." /> : categories.map((category) => {
            const spent = categorySpent(state!, category.id, selectedMonth);
            return <View key={category.id} style={styles.spendRow}><View style={styles.spendLabelRow}><View style={[styles.categoryDot, { backgroundColor: category.color }]} /><Text style={styles.rowTitle}>{category.name}</Text><Text style={styles.rowAmount}>{formatUGX(spent)}</Text></View><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, (spent / maxSpent) * 100)}%`, backgroundColor: category.color }]} /></View></View>;
          })}
        </View>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>QUICK ACTIONS</Text><Text style={styles.sectionTitle}>Keep the ledger moving</Text></View></View>
        <View style={styles.quickGrid}>
          <QuickAction title="Money received" subtitle="Add income" icon="add-circle-outline" onPress={() => openModal("received")} />
          <QuickAction title="I spent" subtitle="Record an expense" icon="remove-circle-outline" onPress={() => openModal("spent")} />
          <QuickAction title="Save today" subtitle="Move to savings" icon="leaf-outline" onPress={() => openModal("save")} />
          <QuickAction title="Auto-budget" subtitle="Split free money" icon="sparkles-outline" onPress={handleAutoBudget} />
        </View>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>RECENTLY</Text><Text style={styles.sectionTitle}>Latest ledger entries</Text></View><Pressable onPress={() => setActiveTab("transactions")}><Text style={styles.linkText}>See all</Text></Pressable></View>
        <View style={styles.card}>{recent.length ? recent.map((transaction) => <TransactionRow key={transaction.id} state={state!} transaction={transaction} onEdit={() => openModal("edit", { transactionId: transaction.id })} onDelete={() => openModal("delete", { transactionId: transaction.id })} />) : <EmptyState text="Your first entry will appear here." />}</View>
        {renderBillsCard()}
        {renderDataButtons()}
      </View>
    );
  }

  function renderBillsCard() {
    return (
      <View style={[styles.card, styles.billCard]} onLayout={(event) => { billsY.current = event.nativeEvent.layout.y; }}>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>MONTHLY BILLS</Text><Text style={styles.sectionTitle}>Nothing should surprise you</Text></View><Pressable style={styles.roundAction} onPress={() => openModal("bill")}><Ionicons name="add" size={19} color={COLORS.ink} /></Pressable></View>
        {state?.bills.length ? state.bills.map((bill) => <BillRow key={bill.id} bill={bill} state={state} month={selectedMonth} onPay={() => handlePayBill(bill)} onEdit={() => openModal("bill", { billId: bill.id })} />) : <Text style={styles.helperText}>Add rent, airtime, school fees, or any repeat payment you want to see coming.</Text>}
      </View>
    );
  }

  function renderDataButtons() {
    return (
      <View style={styles.dataButtons}>
        <Pressable style={styles.outlineButton} onPress={importCsvFromFile}><Ionicons name="arrow-down-circle-outline" size={17} color={COLORS.ink} /><Text style={styles.outlineButtonText}>Import CSV</Text></Pressable>
        <Pressable style={styles.outlineButton} onPress={exportCsv}><Ionicons name="arrow-up-circle-outline" size={17} color={COLORS.ink} /><Text style={styles.outlineButtonText}>Export CSV</Text></Pressable>
      </View>
    );
  }

  function renderTransactions() {
    const allTransactions = [...(state?.transactions ?? [])].sort((a, b) => `${b.date}${b.createdAt}`.localeCompare(`${a.date}${a.createdAt}`));
    const filtered = allTransactions.filter((transaction) => {
      const inMonth = transactionFilter === "all" || monthKey(transaction.date) === selectedMonth;
      const needle = search.trim().toLowerCase();
      return inMonth && (!needle || transactionLabel(state!, transaction).toLowerCase().includes(needle) || transactionMeta(state!, transaction).toLowerCase().includes(needle) || transaction.amount.toString().includes(needle));
    });
    const groups = filtered.reduce<Record<string, Transaction[]>>((accumulator, transaction) => {
      const key = monthKey(transaction.date);
      accumulator[key] = [...(accumulator[key] ?? []), transaction];
      return accumulator;
    }, {});
    return (
      <View style={styles.sectionGap}>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>THE LEDGER</Text><Text style={styles.sectionTitle}>Transactions</Text></View><Pressable onPress={undoLast}><Text style={styles.linkText}>Undo last</Text></Pressable></View>
        <View style={styles.searchBox}><Ionicons name="search-outline" size={18} color={COLORS.muted} /><TextInput value={search} onChangeText={setSearch} placeholder="Search your ledger" placeholderTextColor={COLORS.muted} style={styles.searchInput} /></View>
        <View style={styles.filterRow}><Pressable style={[styles.filterChip, transactionFilter === "month" && styles.filterChipActive]} onPress={() => setTransactionFilter("month")}><Text style={[styles.filterText, transactionFilter === "month" && styles.filterTextActive]}>{formatMonthTitle(selectedMonth)}</Text></Pressable><Pressable style={[styles.filterChip, transactionFilter === "all" && styles.filterChipActive]} onPress={() => setTransactionFilter("all")}><Text style={[styles.filterText, transactionFilter === "all" && styles.filterTextActive]}>All months</Text></Pressable></View>
        {Object.keys(groups).length ? Object.entries(groups).map(([month, transactions]) => <View key={month} style={styles.group}><Text style={styles.groupTitle}>{formatMonthTitle(month)}</Text><View style={styles.card}>{transactions.map((transaction) => <TransactionRow key={transaction.id} state={state!} transaction={transaction} onEdit={() => openModal("edit", { transactionId: transaction.id })} onDelete={() => openModal("delete", { transactionId: transaction.id })} />)}</View></View>) : <View style={styles.card}><EmptyState text="No ledger entries match this view yet." /></View>}
        {renderDataButtons()}
      </View>
    );
  }

  function renderBudgets() {
    const categories = state?.categories.filter((category) => category.kind === "budget" && !category.archived) ?? [];
    return (
      <View style={styles.sectionGap}>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>GIVE IT A PLACE</Text><Text style={styles.sectionTitle}>Budgets</Text></View><Pressable style={styles.primarySmall} onPress={handleAutoBudget}><Ionicons name="sparkles-outline" size={15} color={COLORS.ink} /><Text style={styles.primarySmallText}>Auto-budget</Text></Pressable></View>
        <Text style={styles.helperText}>Set a plan for {formatMonthTitle(selectedMonth)}, then move money from Not yet budgeted when it arrives.</Text>
        <View style={styles.card}>
          {categories.map((category) => {
            const budget = budgetFor(state!, category.id, selectedMonth).amount;
            const spent = categorySpent(state!, category.id, selectedMonth);
            const balance = categoryBalance(state!, category.id);
            return <Pressable key={category.id} style={styles.budgetRow} onPress={() => openModal("plan", { categoryId: category.id })}><View style={styles.budgetRowTop}><View style={styles.budgetTitle}><View style={[styles.categoryDot, { backgroundColor: category.color }]} /><Text style={styles.rowTitle}>{category.name}</Text></View><Pressable onPress={() => openModal("plan", { categoryId: category.id })}><Text style={styles.linkText}>{budget ? "Edit plan" : "Plan"}</Text></Pressable></View><View style={styles.budgetNumbers}><Text style={styles.budgetSpent}>{formatUGX(spent)} <Text style={styles.mutedInline}>of {formatUGX(budget)}</Text></Text><Text style={[styles.budgetLeft, balance < 0 && styles.dangerText]}>{formatUGX(Math.max(0, balance))} left</Text></View><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress(spent, budget) * 100}%`, backgroundColor: category.color }]} /></View><View style={styles.budgetRowBottom}><Text style={styles.mutedSmall}>{budget ? `${Math.round(progress(spent, budget) * 100)}% of plan used` : "No plan yet"}</Text><Pressable onPress={() => deleteCategory(category)}><Ionicons name="trash-outline" size={16} color={COLORS.muted} /></Pressable></View></Pressable>;
          })}
          {!categories.length && <EmptyState text="No active budgets yet." />}
        </View>
        <View style={styles.lavenderCard}><View><Text style={styles.cardEyebrow}>CATEGORIES</Text><Text style={styles.sectionTitle}>Make the plan fit your life</Text><Text style={styles.helperText}>Create a budget that sounds like you.</Text></View><Pressable style={styles.lavenderButton} onPress={() => openModal("category")}><Ionicons name="add" size={18} color={COLORS.ink} /><Text style={styles.lavenderButtonText}>Create a category</Text></Pressable></View>
        {renderBillsCard()}
      </View>
    );
  }

  function renderSavings() {
    const savingsHistory = [...(state?.transactions ?? [])].filter((transaction) => transaction.to === "savings" || transaction.from === "savings").sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return (
      <View style={styles.sectionGap}>
        <View style={styles.savingsHero}><View style={styles.heroTopLine}><Text style={styles.heroEyebrow}>SAVINGS, WITHOUT THE DRAMA</Text><Ionicons name="leaf-outline" size={19} color={COLORS.mint} /></View><Text style={styles.heroAmount}>{formatUGX(savingsBalance)}</Text><Text style={styles.heroSubtitle}>A quiet place for future-you.</Text><View style={styles.owedPill}><Text style={styles.owedPillLabel}>OWED BACK</Text><Text style={styles.owedPillValue}>{formatUGX(owed)}</Text></View></View>
        <View style={styles.quickGrid}><QuickAction title="Save today" subtitle="Move free money" icon="leaf-outline" onPress={() => openModal("save")} /><QuickAction title="Repay savings" subtitle={owed ? `Clear ${formatUGX(owed)}` : "Nothing owed back"} icon="refresh-outline" onPress={() => openModal("repayment")} /></View>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>SAVINGS HISTORY</Text><Text style={styles.sectionTitle}>Every step counts</Text></View></View>
        <View style={styles.card}>{savingsHistory.length ? savingsHistory.map((transaction) => <TransactionRow key={transaction.id} state={state!} transaction={transaction} onEdit={() => openModal("edit", { transactionId: transaction.id })} onDelete={() => openModal("delete", { transactionId: transaction.id })} />) : <EmptyState text="Save your first amount and it will show here." />}</View>
      </View>
    );
  }

  function renderGoals() {
    const goals = state?.categories.filter((category) => category.kind === "goal" && !category.archived) ?? [];
    return (
      <View style={styles.sectionGap}>
        <View style={styles.sectionHeader}><View><Text style={styles.sectionEyebrow}>A REASON TO KEEP GOING</Text><Text style={styles.sectionTitle}>Goals</Text></View><Pressable style={styles.primarySmall} onPress={() => openModal("goal")}><Ionicons name="add" size={15} color={COLORS.ink} /><Text style={styles.primarySmallText}>New goal</Text></Pressable></View>
        <Text style={styles.helperText}>Goals are buckets with a finish line. Add money from Not yet budgeted whenever you can.</Text>
        {goals.length ? goals.map((goal) => {
          const balance = categoryBalance(state!, goal.id);
          const target = goal.target ?? 0;
          return <View key={goal.id} style={styles.goalCard}><View style={styles.budgetRowTop}><View style={styles.budgetTitle}><View style={[styles.categoryDot, { backgroundColor: goal.color }]} /><Text style={styles.rowTitle}>{goal.name}</Text></View><Text style={styles.goalPercent}>{target ? `${Math.round(progress(balance, target) * 100)}%` : "Open"}</Text></View><Text style={styles.goalAmount}>{formatUGX(balance)} <Text style={styles.mutedInline}>of {formatUGX(target)}</Text></Text><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress(balance, target) * 100}%`, backgroundColor: goal.color }]} /></View><View style={styles.budgetRowBottom}><Text style={styles.mutedSmall}>{target && balance >= target ? "Goal reached" : target ? `${formatUGX(Math.max(0, target - balance))} to go` : "Add a target in your plan"}</Text><Pressable style={styles.smallAction} onPress={() => openModal("save", { categoryId: goal.id })}><Text style={styles.smallActionText}>Add money</Text></Pressable></View></View>;
        }) : <View style={styles.card}><EmptyState text="Create a goal for something that matters to you." /></View>}
      </View>
    );
  }

  function renderModalContent() {
    if (!state || !modal) return null;
    if (modal === "settings") return <View style={styles.modalStack}>
      <Text style={styles.modalIntro}>Your ledger remains local-first. Cloud backup is end-to-end encrypted on this device with your recovery passphrase; the server stores only an unreadable encrypted blob and never receives your PIN, card PIN, OTP, or payment authority.</Text>
      <View style={styles.cloudPanel}>
        <View style={styles.budgetRowTop}><View><Text style={styles.sectionEyebrow}>OPTIONAL CLOUD BACKUP</Text><Text style={styles.rowTitle}>{cloudUser ? `Signed in${cloudUser.name ? ` as ${cloudUser.name}` : ""}` : "Not connected"}</Text></View><View style={[styles.syncDot, cloudStatus === "synced" && styles.syncDotGood, cloudStatus === "conflict" && styles.syncDotWarn]} /></View>
        <Text style={styles.mutedSmall}>{cloudStatus === "syncing" ? "Syncing your encrypted snapshot…" : cloudStatus === "synced" ? `Last synced${cloudInfo?.updatedAt ? ` ${formatDateLong(cloudInfo.updatedAt.slice(0, 10))}` : " just now"}.` : cloudStatus === "conflict" ? "Another device changed the backup. Restore it before uploading again." : cloudUser ? "Local changes sync in the background when online." : "Sign in only when you want cloud backup."}</Text>
        {!cloudUser ? <PrimaryButton title="Sign in for cloud backup" onPress={() => void signInToCloud()} /> : <>
          <View style={styles.e2ePanel}><Text style={styles.sectionEyebrow}>END-TO-END ENCRYPTION</Text><Text style={styles.mutedSmall}>{e2ePassphrase ? "Ready for this session. The server cannot decrypt your backup." : "Set a recovery passphrase of at least 12 characters. You must enter it again on another device."}</Text><Field label="Recovery passphrase" value={form.recoveryPassphrase ?? ""} onChangeText={(value) => updateForm("recoveryPassphrase", value)} placeholder="At least 12 characters" secureTextEntry /><Field label="Confirm passphrase" value={form.recoveryConfirm ?? ""} onChangeText={(value) => updateForm("recoveryConfirm", value)} placeholder="Repeat the passphrase" secureTextEntry /><PrimaryButton title={e2ePassphrase ? "Replace session passphrase" : "Use passphrase for this session"} onPress={setRecoveryPassphrase} />{e2ePassphrase ? <SecondaryButton title="Clear session passphrase" onPress={clearRecoveryPassphrase} /> : null}</View>
          <Pressable style={styles.checkRow} onPress={() => void toggleCloudBackup()}><View style={[styles.checkbox, cloudPreferences?.enabled && styles.checkboxActive]}>{cloudPreferences?.enabled && <Ionicons name="checkmark" size={14} color={COLORS.ink} />}</View><View><Text style={styles.rowTitle}>Enable cloud backup</Text><Text style={styles.mutedSmall}>Your device stays usable offline.</Text></View></Pressable>
          <View style={styles.dataButtons}><SecondaryButton title="Back up now" onPress={() => void backupCloud()} /><SecondaryButton title="Restore latest" onPress={() => void restoreCloud()} /></View>
          <ModalButton icon="log-out-outline" title="Disconnect cloud account" onPress={() => void signOutOfCloud()} disabled={cloudBusy} />
        </>}
      </View>
      <ModalButton icon="lock-closed-outline" title={state.pinHash ? "Change PIN lock" : "Set a PIN lock"} onPress={() => openModal("pin")} /><ModalButton icon="shield-checkmark-outline" title="Restore JSON backup" onPress={() => openModal("backup", { mode: "restore" })} /><ModalButton icon="download-outline" title="Share JSON backup" onPress={() => void shareBackup()} /><ModalButton icon="close-circle-outline" title="Remove PIN lock" danger={!state.pinHash} onPress={removePin} disabled={!state.pinHash} />
    </View>;
    if (modal === "edit") {
      const transaction = state.transactions.find((entry) => entry.id === modalPayload.transactionId);
      if (!transaction) return <View style={styles.modalStack}><Text style={styles.modalIntro}>That entry is no longer available.</Text><SecondaryButton title="Close" onPress={closeModal} /></View>;
      return <View style={styles.modalStack}><Text style={styles.modalIntro}>Correct the details below. Balances will be recalculated from the updated ledger.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Field label="Date" value={form.date ?? transaction.date} onChangeText={(value) => updateForm("date", value)} placeholder="YYYY-MM-DD" />{transaction.type === "expense" && <><Text style={styles.fieldLabel}>Spend from</Text><ChoiceChips value={form.source || transaction.from || "free"} options={sourceOptions(state, true)} onChange={(value) => updateForm("source", value)} /></>}<Field label="Note" value={form.note ?? ""} onChangeText={(value) => updateForm("note", value)} placeholder="Optional note" /><PrimaryButton title="Save corrected entry" onPress={editTransaction} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    }
    if (modal === "delete") {
      const transaction = state.transactions.find((entry) => entry.id === modalPayload.transactionId);
      return <View style={styles.modalStack}><Text style={styles.modalIntro}>Delete {transaction ? transactionLabel(state, transaction) : "this entry"}? This permanently changes the ledger and recalculates your balances.</Text><PrimaryButton title="Delete entry" onPress={deleteTransaction} /><SecondaryButton title="Keep entry" onPress={closeModal} /></View>;
    }
    if (modal === "move") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Move money into {moneySourceLabel(state, modalPayload.categoryId)}. Not yet budgeted has {formatUGX(freeBalance)}.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Text style={styles.fieldLabel}>Take it from</Text><ChoiceChips value={form.source || "free"} options={sourceOptions(state, true).filter((option) => option.id !== modalPayload.categoryId)} onChange={(value) => updateForm("source", value)} /><Field label="Note" value={form.note ?? ""} onChangeText={(value) => updateForm("note", value)} placeholder="Optional note" /><PrimaryButton title="Move money" onPress={handleMove} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "pay") {
      const bill = state.bills.find((entry) => entry.id === modalPayload.billId);
      if (!bill) return <View style={styles.modalStack}><Text style={styles.modalIntro}>That bill is no longer available.</Text><SecondaryButton title="Close" onPress={closeModal} /></View>;
      const source = form.source || bill.sourceId;
      const have = bucketBalance(state.transactions, source);
      const short = Math.max(0, bill.amount - have);
      const canTopUp = source !== "free" && source !== "savings" && short > 0 && freeBalance >= short;
      return <View style={styles.modalStack}><Text style={styles.modalIntro}>{bill.name} needs {formatUGX(bill.amount)}. {moneySourceLabel(state, source)} has {formatUGX(have)}.</Text><Text style={styles.fieldLabel}>Pay from</Text><ChoiceChips value={source} options={sourceOptions(state, true)} onChange={(value) => updateForm("source", value)} />{short === 0 ? <PrimaryButton title="Pay now" onPress={() => payBill(bill, source, 0)} /> : canTopUp ? <PrimaryButton title={`Move ${formatUGX(short)} from Not yet budgeted and pay`} onPress={() => payBill(bill, source, short)} /> : <Text style={styles.helperText}>Not enough here, and Not yet budgeted has {formatUGX(freeBalance)}. Add money received first, or pick another source.</Text>}<SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    }
    if (modal === "auto") return <View style={styles.modalStack}><Text style={styles.modalIntro}>We’ll split {formatUGX(freeBalance)} by the planned amounts below. The shares add up exactly.</Text>{confirmAuto.map(({ category, amount }) => <View key={category.id} style={styles.confirmRow}><View style={styles.budgetTitle}><View style={[styles.categoryDot, { backgroundColor: category.color }]} /><Text style={styles.rowTitle}>{category.name}</Text></View><Text style={styles.rowAmount}>{formatUGX(amount)}</Text></View>)}<PrimaryButton title="Apply these shares" onPress={confirmAutoBudget} /><SecondaryButton title="Not yet" onPress={closeModal} /></View>;
    if (modal === "backup") return <View style={styles.modalStack}><Text style={styles.modalIntro}>{modalPayload.mode === "export" ? "This is your full Pocket Budget backup. Save it somewhere safe or share it with yourself." : "Paste a Pocket Budget JSON backup below to restore it. This replaces the current device ledger."}</Text><TextInput multiline value={backupText} onChangeText={setBackupText} placeholder="Paste JSON backup here" placeholderTextColor={COLORS.muted} style={[styles.input, styles.textArea]} autoCapitalize="none" /><PrimaryButton title={modalPayload.mode === "export" ? "Download / share backup" : "Restore this backup"} onPress={modalPayload.mode === "export" ? () => void shareBackup() : restoreBackup} /><SecondaryButton title="Close" onPress={closeModal} /></View>;
    if (modal === "pin") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Choose 4 to 6 digits. This is a light privacy layer, not encrypted storage.</Text><Field label="PIN" value={form.pin ?? ""} onChangeText={(value) => updateForm("pin", formatInputValue(value))} placeholder="1234" secureTextEntry keyboardType="number-pad" /><Field label="Confirm PIN" value={form.confirm ?? ""} onChangeText={(value) => updateForm("confirm", formatInputValue(value))} placeholder="1234" secureTextEntry keyboardType="number-pad" /><PrimaryButton title="Enable PIN lock" onPress={savePin} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "plan") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Rename this budget and set how much you plan for {formatMonthTitle(selectedMonth)}.</Text><Field label="Budget name" value={form.name ?? ""} onChangeText={(value) => updateForm("name", value)} placeholder="Name" /><Field label="Planned amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><PrimaryButton title="Save" onPress={handlePlan} /><SecondaryButton title="Move money into this budget" onPress={() => openModal("move", { categoryId: modalPayload.categoryId })} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "category") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Give this budget a simple name. You can change its plan later.</Text><Field label="Category name" value={form.name ?? ""} onChangeText={(value) => updateForm("name", value)} placeholder="School, family, side project…" /><Field label="Plan for this month" value={form.planned ?? ""} onChangeText={(value) => updateForm("planned", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><ColorPicker value={form.color ?? COLORS.mintDark} onChange={(value) => updateForm("color", value)} /><PrimaryButton title="Create a category" onPress={handleCategory} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "goal") return <View style={styles.modalStack}><Text style={styles.modalIntro}>A goal gives your saving a name and a finish line.</Text><Field label="Goal name" value={form.name ?? ""} onChangeText={(value) => updateForm("name", value)} placeholder="New phone, rent buffer…" /><Field label="Target amount" value={form.target ?? ""} onChangeText={(value) => updateForm("target", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><ColorPicker value={form.color ?? COLORS.lavenderDark} onChange={(value) => updateForm("color", value)} /><PrimaryButton title="Create goal" onPress={handleGoal} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "bill") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Add a repeat payment so the month can remind you gently.</Text><Field label="Bill name" value={form.name ?? ""} onChangeText={(value) => updateForm("name", value)} placeholder="Rent, airtime, school fees…" /><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Field label="Due day" value={form.dueDay ?? "1"} onChangeText={(value) => updateForm("dueDay", formatInputValue(value))} placeholder="1" keyboardType="number-pad" /><Text style={styles.fieldLabel}>Pay from</Text><ChoiceChips value={form.source || "free"} options={sourceOptions(state, true)} onChange={(value) => updateForm("source", value)} /><PrimaryButton title={modalPayload.billId ? "Save bill" : "Add monthly bill"} onPress={handleBill} />{modalPayload.billId ? <SecondaryButton title="Delete this bill" onPress={deleteBill} /> : null}<SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "received") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Income lands in Not yet budgeted until you give it a place.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Field label="Date" value={form.date ?? todayISO()} onChangeText={(value) => updateForm("date", value)} placeholder="YYYY-MM-DD" /><Field label="Note" value={form.note ?? ""} onChangeText={(value) => updateForm("note", value)} placeholder="Salary, side work…" /><PrimaryButton title="Add money received" onPress={handleReceived} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "spent") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Choose the bucket this expense should come from.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Text style={styles.fieldLabel}>Spend from</Text><ChoiceChips value={form.source || "free"} options={sourceOptions(state, true)} onChange={(value) => updateForm("source", value)} /><Field label="Date" value={form.date ?? todayISO()} onChangeText={(value) => updateForm("date", value)} placeholder="YYYY-MM-DD" /><Field label="Note" value={form.note ?? ""} onChangeText={(value) => updateForm("note", value)} placeholder="What was it for?" />{form.source === "savings" && <Pressable style={styles.checkRow} onPress={() => updateForm("emergency", form.emergency === "yes" ? "no" : "yes")}><View style={[styles.checkbox, form.emergency === "yes" && styles.checkboxActive]}>{form.emergency === "yes" && <Ionicons name="checkmark" size={14} color={COLORS.ink} />}</View><View><Text style={styles.rowTitle}>Mark as emergency spend</Text><Text style={styles.mutedSmall}>This adds to Owed back.</Text></View></Pressable>}<PrimaryButton title="Record expense" onPress={handleSpent} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "save") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Move money from Not yet budgeted into {modalPayload.categoryId ? moneySourceLabel(state, modalPayload.categoryId) : "savings"}. You can give it a note for future-you.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder="0" keyboardType="number-pad" prefix="UGX" /><Field label="Date" value={form.date ?? todayISO()} onChangeText={(value) => updateForm("date", value)} placeholder="YYYY-MM-DD" /><Field label="Note" value={form.note ?? ""} onChangeText={(value) => updateForm("note", value)} placeholder="Rainy day, buffer…" /><PrimaryButton title={modalPayload.categoryId ? "Add to goal" : "Move into savings"} onPress={handleSaveToday} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    if (modal === "repayment") return <View style={styles.modalStack}><Text style={styles.modalIntro}>Repayment moves money from Not yet budgeted into savings and reduces Owed back.</Text><Field label="Amount" value={form.amount ?? ""} onChangeText={(value) => updateForm("amount", formatInputValue(value))} placeholder={String(owed)} keyboardType="number-pad" prefix="UGX" /><Text style={styles.helperText}>Owed back right now: {formatUGX(owed)}</Text><PrimaryButton title="Repay savings" onPress={handleRepayment} /><SecondaryButton title="Cancel" onPress={closeModal} /></View>;
    return null;
  }

  if (!state) return <ScreenContainer><View style={styles.loading}><ActivityIndicator size="small" color={COLORS.ink} /><Text style={styles.loadingText}>Opening your calm ledger…</Text></View></ScreenContainer>;

  if (!unlocked && state.pinHash) {
    return <ScreenContainer><View style={styles.lockScreen}><View style={styles.walletMarkLarge}><Text style={styles.walletMarkTextLarge}>P</Text></View><Text style={styles.eyebrow}>YOUR CALM LEDGER</Text><Text style={styles.lockTitle}>Pocket Budget</Text><Text style={styles.lockCopy}>A small pause before your numbers open.</Text><TextInput value={unlockPin} onChangeText={(value) => setUnlockPin(formatInputValue(value))} placeholder="Enter PIN" placeholderTextColor={COLORS.muted} secureTextEntry keyboardType="number-pad" style={[styles.input, styles.pinInput]} /><PrimaryButton title="Unlock ledger" onPress={unlock} /><Text style={styles.mutedSmall}>Your PIN only protects against casual snooping. Your stored ledger is not encrypted.</Text></View></ScreenContainer>;
  }

  return (
    <ScreenContainer safeAreaClassName="bg-background" edges={["top", "left", "right"]}>
      <Animated.View style={[styles.outer, { opacity: entrance, transform: [{ translateY: entrance.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) }] }]}>
        <ScrollView ref={scrollRef} contentContainerStyle={[styles.content, { maxWidth: pageWidth }]} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {renderHeader()}
          {renderMonthSwitcher()}
          {renderHero()}
          {renderHint()}
          {renderTabs()}
          <View onLayout={(event) => { tabContentY.current = event.nativeEvent.layout.y; }}>
            {activeTab === "overview" && renderOverview()}
            {activeTab === "transactions" && renderTransactions()}
            {activeTab === "budgets" && renderBudgets()}
            {activeTab === "savings" && renderSavings()}
            {activeTab === "goals" && renderGoals()}
          </View>
        </ScrollView>
        <Pressable style={styles.fab} onPress={() => openModal("received")} accessibilityLabel="Add ledger entry"><Ionicons name="add" size={30} color={COLORS.darkInk} /></Pressable>
        {notice || errorNotice ? <View style={[styles.toast, errorNotice && styles.toastError]}><Ionicons name={errorNotice ? "alert-circle-outline" : "checkmark-circle-outline"} size={17} color={errorNotice ? COLORS.white : COLORS.mint} /><Text style={styles.toastText}>{errorNotice || notice}</Text></View> : null}
      </Animated.View>
      <Modal visible={Boolean(modal)} transparent animationType="slide" onRequestClose={closeModal}>
        <KeyboardAvoidingView style={styles.modalOverlay} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}>
          <Pressable style={styles.modalDismissArea} onPress={closeModal} />
          <View style={styles.modalSheet}><View style={styles.modalHandle} /><View style={styles.modalHeader}><Text style={styles.modalTitle}>{modal === "settings" ? "Data & safety" : modal === "auto" ? "Auto-budget" : modal === "backup" ? "JSON backup" : modal === "pin" ? "PIN lock" : modal === "edit" ? "Edit entry" : modal === "delete" ? "Delete entry" : modal === "goal" ? "New goal" : modal === "bill" ? "Monthly bill" : modal === "category" ? "New category" : modal === "plan" ? "Edit budget" : modal === "move" ? "Move money" : modal === "pay" ? "Pay bill" : modal === "spent" ? "I spent" : modal === "save" ? "Save today" : modal === "repayment" ? "Repay savings" : "Money received"}</Text><Pressable onPress={closeModal} style={styles.closeButton}><Ionicons name="close" size={22} color={COLORS.ink} /></Pressable></View><ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled">{renderModalContent()}</ScrollView></View>
        </KeyboardAvoidingView>
      </Modal>
    </ScreenContainer>
  );
}

function sourceOptions(state: BudgetState, includeFree = false): Array<{ id: string; label: string }> {
  return [
    ...(includeFree ? [{ id: "free", label: "Not yet budgeted" }] : []),
    { id: "savings", label: "Savings" },
    ...state.categories.filter((category) => !category.archived && (category.kind === "budget" || category.kind === "goal")).map((category) => ({ id: category.id, label: category.name })),
  ];
}

function IconButton({ icon, label, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void }) {
  return <Pressable style={styles.iconButton} onPress={onPress} accessibilityLabel={label}><Ionicons name={icon} size={19} color={COLORS.ink} /></Pressable>;
}

function Metric({ label, value }: { label: string; value: number }) {
  return <View style={styles.metric}><Text style={styles.metricLabel}>{label}</Text><Text style={styles.metricValue}>{formatUGX(value)}</Text></View>;
}

function MiniCard({ label, value, tint, icon, onPress }: { label: string; value: number; tint: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  return <Pressable style={[styles.miniCard, { backgroundColor: tint }]} onPress={onPress}><View style={styles.miniIcon}><Ionicons name={icon} size={17} color={COLORS.ink} /></View><Text style={styles.miniLabel}>{label}</Text><Text style={styles.miniValue}>{formatUGX(value)}</Text><Ionicons name="arrow-up-outline" size={16} color={COLORS.inkSoft} style={styles.miniArrow} /></Pressable>;
}

function QuickAction({ title, subtitle, icon, onPress }: { title: string; subtitle: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  return <Pressable style={({ pressed }) => [styles.quickAction, pressed && styles.pressed]} onPress={onPress}><View style={styles.quickIcon}><Ionicons name={icon} size={20} color={COLORS.ink} /></View><View style={styles.quickCopy}><Text style={styles.quickTitle}>{title}</Text><Text style={styles.quickSubtitle}>{subtitle}</Text></View><Ionicons name="chevron-forward" size={17} color={COLORS.muted} /></Pressable>;
}

function TransactionRow({ state, transaction, onEdit, onDelete }: { state: BudgetState; transaction: Transaction; onEdit: () => void; onDelete: () => void }) {
  const positive = transaction.type === "income" || transaction.to === "savings" || transaction.to === transaction.categoryId;
  return <View style={styles.transactionRow}><View style={[styles.transactionIcon, { backgroundColor: positive ? COLORS.mint : COLORS.cream }]}><Ionicons name={positive ? "arrow-down-outline" : transaction.repayment ? "refresh-outline" : "arrow-up-outline"} size={17} color={COLORS.ink} /></View><View style={styles.transactionCopy}><Text style={styles.rowTitle}>{transactionLabel(state, transaction)}</Text><Text style={styles.mutedSmall}>{formatDateLong(transaction.date)} · {transactionMeta(state, transaction)}</Text></View><Text style={[styles.transactionAmount, positive ? styles.positiveText : styles.negativeText]}>{positive ? "+" : "−"}{formatUGX(transaction.amount).replace("UGX ", "UGX ")}</Text><View style={styles.transactionActions}><Pressable onPress={onEdit} accessibilityLabel="Edit entry"><Ionicons name="create-outline" size={17} color={COLORS.inkSoft} /></Pressable><Pressable onPress={onDelete} accessibilityLabel="Delete entry"><Ionicons name="trash-outline" size={17} color={COLORS.danger} /></Pressable></View></View>;
}

function BillRow({ bill, state, month, onPay, onEdit }: { bill: Bill; state: BudgetState; month: string; onPay: () => void; onEdit: () => void }) {
  const paid = isBillPaid(state, bill, month);
  const overdue = isBillOverdue(state, bill, month);
  return <View style={styles.billRow}><Pressable style={styles.billCopy} onPress={onEdit}><Text style={styles.rowTitle}>{bill.name}</Text><Text style={styles.mutedSmall}>{formatUGX(bill.amount)} · due {bill.dueDay} · from {moneySourceLabel(state, bill.sourceId)} · tap to edit</Text></Pressable>{paid ? <View style={styles.statusPill}><Text style={styles.statusPillText}>✓ Paid</Text></View> : <Pressable style={[styles.payButton, overdue && styles.payButtonWarm]} onPress={onPay}><Text style={styles.payButtonText}>{overdue ? "Pay now" : "Pay"}</Text></Pressable>}</View>;
}

function EmptyState({ text }: { text: string }) {
  return <View style={styles.emptyState}><Ionicons name="sparkles-outline" size={21} color={COLORS.mintDark} /><Text style={styles.emptyText}>{text}</Text></View>;
}

function Field({ label, value, onChangeText, placeholder, keyboardType, prefix, secureTextEntry }: { label: string; value: string; onChangeText: (value: string) => void; placeholder?: string; keyboardType?: "number-pad" | "default"; prefix?: string; secureTextEntry?: boolean }) {
  return <View style={styles.field}><Text style={styles.fieldLabel}>{label}</Text><View style={styles.inputWrap}>{prefix ? <Text style={styles.inputPrefix}>{prefix}</Text> : null}<TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={COLORS.muted} keyboardType={keyboardType} secureTextEntry={secureTextEntry} style={styles.input} /></View></View>;
}

function ChoiceChips({ value, options, onChange }: { value: string; options: Array<{ id: string; label: string }>; onChange: (value: string) => void }) {
  return <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.choiceScroller}>{options.map((option) => <Pressable key={option.id} style={[styles.choiceChip, value === option.id && styles.choiceChipActive]} onPress={() => onChange(option.id)}><Text style={[styles.choiceChipText, value === option.id && styles.choiceChipTextActive]}>{option.label}</Text></Pressable>)}</ScrollView>;
}

function ColorPicker({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const colors = [COLORS.mintDark, COLORS.coral, COLORS.slate, COLORS.blue, COLORS.lavenderDark, COLORS.ink];
  return <View style={styles.colorPicker}>{colors.map((color) => <Pressable key={color} onPress={() => onChange(color)} style={[styles.colorSwatch, { backgroundColor: color }, value === color && styles.colorSwatchSelected]} />)}</View>;
}

function PrimaryButton({ title, onPress }: { title: string; onPress: () => void }) {
  return <Pressable style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]} onPress={onPress}><Text style={styles.primaryButtonText}>{title}</Text></Pressable>;
}

function SecondaryButton({ title, onPress }: { title: string; onPress: () => void }) {
  return <Pressable style={styles.secondaryButton} onPress={onPress}><Text style={styles.secondaryButtonText}>{title}</Text></Pressable>;
}

function ModalButton({ icon, title, onPress, danger = false, disabled = false }: { icon: keyof typeof Ionicons.glyphMap; title: string; onPress: () => void; danger?: boolean; disabled?: boolean }) {
  return <Pressable disabled={disabled} style={[styles.modalButton, disabled && styles.disabledButton]} onPress={onPress}><Ionicons name={icon} size={20} color={danger ? COLORS.danger : COLORS.ink} /><Text style={[styles.modalButtonText, danger && styles.dangerText]}>{title}</Text><Ionicons name="chevron-forward" size={17} color={COLORS.muted} /></Pressable>;
}

const styles = StyleSheet.create({
  outer: { flex: 1, backgroundColor: COLORS.cream, alignItems: "center" },
  content: { width: "100%", alignSelf: "center", paddingHorizontal: 16, paddingTop: 8, paddingBottom: 116 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, backgroundColor: COLORS.cream },
  loadingText: { color: COLORS.muted, fontSize: 14 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 14, gap: 12 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 11 },
  walletMark: { width: 39, height: 39, borderRadius: 12, backgroundColor: COLORS.darkInk, alignItems: "center", justifyContent: "center" },
  walletMarkText: { color: COLORS.mintDark, fontSize: 21, fontWeight: "800", fontStyle: "italic" },
  walletMarkLarge: { width: 72, height: 72, borderRadius: 22, backgroundColor: COLORS.darkInk, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  walletMarkTextLarge: { color: COLORS.mintDark, fontSize: 39, fontWeight: "800", fontStyle: "italic" },
  eyebrow: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.6 },
  wordmark: { color: COLORS.ink, fontSize: 20, fontWeight: "800", letterSpacing: -0.4, marginTop: 2 },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 4 },
  iconButton: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.border },
  monthRow: { flexDirection: "row", alignItems: "center", marginTop: 11, marginBottom: 17, gap: 8 },
  monthArrow: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, alignItems: "center", justifyContent: "center" },
  monthCenter: { flex: 1, alignItems: "center" },
  monthTitle: { color: COLORS.ink, fontSize: 18, fontWeight: "800", marginTop: 2 },
  todayChip: { borderRadius: 14, backgroundColor: COLORS.mint, paddingHorizontal: 10, paddingVertical: 7 },
  todayChipText: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  hero: { backgroundColor: COLORS.darkInk, borderRadius: 23, padding: 21, minHeight: 204, justifyContent: "space-between", shadowColor: COLORS.darkInk, shadowOpacity: 0.35, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, elevation: 4 },
  heroTopLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  heroEyebrow: { color: COLORS.mintDark, fontSize: 10, fontWeight: "800", letterSpacing: 1.6 },
  heroDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.mintDark },
  heroAmount: { color: COLORS.white, fontSize: 37, fontWeight: "900", letterSpacing: -1.4, marginTop: 20 },
  heroSubtitle: { color: "#B9CAC4", fontSize: 13, lineHeight: 19, marginTop: 4 },
  heroMetrics: { flexDirection: "row", borderTopWidth: 1, borderTopColor: "#36504B", marginTop: 21, paddingTop: 15, gap: 13 },
  metric: { flex: 1 },
  metricLabel: { color: "#8DA69F", fontSize: 11, marginBottom: 4 },
  metricValue: { color: COLORS.white, fontSize: 13, fontWeight: "800" },
  hintCard: { flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: COLORS.mint, borderRadius: 17, padding: 14, marginTop: 13 },
  hintCardWarm: { backgroundColor: "#4A2D2A" },
  hintIcon: { width: 33, height: 33, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.54)", alignItems: "center", justifyContent: "center" },
  hintCopy: { flex: 1 },
  cardEyebrow: { color: COLORS.inkSoft, fontSize: 10, fontWeight: "800", letterSpacing: 1.3 },
  hintText: { color: COLORS.ink, fontSize: 13, lineHeight: 18, marginTop: 2 },
  smallAction: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 12, backgroundColor: COLORS.paper },
  smallActionText: { color: COLORS.ink, fontSize: 11, fontWeight: "800" },
  tabScroller: { gap: 8, paddingVertical: 16 },
  tab: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 13, paddingVertical: 9, borderRadius: 15, backgroundColor: "transparent" },
  tabActive: { backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.border },
  tabText: { color: COLORS.muted, fontSize: 12, fontWeight: "700" },
  tabTextActive: { color: COLORS.ink },
  sectionGap: { gap: 16 },
  twoColumn: { flexDirection: "row", gap: 12 },
  miniCard: { flex: 1, minHeight: 126, borderRadius: 19, padding: 15, position: "relative" },
  miniIcon: { width: 31, height: 31, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.62)", alignItems: "center", justifyContent: "center", marginBottom: 10 },
  miniLabel: { color: COLORS.inkSoft, fontSize: 12, fontWeight: "700" },
  miniValue: { color: COLORS.ink, fontSize: 18, fontWeight: "900", marginTop: 4 },
  miniArrow: { position: "absolute", right: 14, top: 16 },
  sectionHeader: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", gap: 12 },
  sectionEyebrow: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.4 },
  sectionTitle: { color: COLORS.ink, fontSize: 19, fontWeight: "800", letterSpacing: -0.3, marginTop: 3 },
  sectionMeta: { color: COLORS.muted, fontSize: 12, fontWeight: "700" },
  linkText: { color: COLORS.lavenderDark, fontSize: 12, fontWeight: "800" },
  card: { backgroundColor: COLORS.paper, borderRadius: 19, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  spendRow: { marginBottom: 15 },
  spendLabelRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 },
  categoryDot: { width: 9, height: 9, borderRadius: 4.5 },
  rowTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "800", flex: 1 },
  rowAmount: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  progressTrack: { height: 7, backgroundColor: "#2A3A35", borderRadius: 5, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 5, minWidth: 2 },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  quickAction: { width: "48.4%", minHeight: 72, flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 16, backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.border },
  quickIcon: { width: 32, height: 32, borderRadius: 11, backgroundColor: COLORS.mint, alignItems: "center", justifyContent: "center" },
  quickCopy: { flex: 1 },
  quickTitle: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  quickSubtitle: { color: COLORS.muted, fontSize: 10, marginTop: 2, lineHeight: 14 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
  billCard: { gap: 12 },
  roundAction: { width: 31, height: 31, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.mint },
  helperText: { color: COLORS.muted, fontSize: 13, lineHeight: 19 },
  dataButtons: { flexDirection: "row", gap: 10 },
  outlineButton: { flex: 1, minHeight: 43, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 },
  outlineButtonText: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  searchBox: { height: 47, borderRadius: 15, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, flexDirection: "row", alignItems: "center", paddingHorizontal: 14, gap: 8 },
  searchInput: { flex: 1, color: COLORS.ink, fontSize: 13, paddingVertical: 0 },
  filterRow: { flexDirection: "row", gap: 8 },
  filterChip: { borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, paddingHorizontal: 12, paddingVertical: 8 },
  filterChipActive: { backgroundColor: COLORS.darkInk, borderColor: COLORS.darkInk },
  filterText: { color: COLORS.muted, fontSize: 11, fontWeight: "700" },
  filterTextActive: { color: COLORS.white },
  group: { gap: 9 },
  groupTitle: { color: COLORS.inkSoft, fontSize: 12, fontWeight: "800", marginLeft: 3 },
  transactionRow: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "#2A3A35" },
  transactionIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  transactionCopy: { flex: 1 },
  transactionActions: { flexDirection: "row", alignItems: "center", gap: 10, marginLeft: 4 },
  mutedSmall: { color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  transactionAmount: { fontSize: 12, fontWeight: "900" },
  positiveText: { color: COLORS.mintDark },
  negativeText: { color: COLORS.coral },
  lavenderCard: { backgroundColor: COLORS.lavender, borderRadius: 20, padding: 17, gap: 14 },
  lavenderButton: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 13, backgroundColor: COLORS.paper, paddingHorizontal: 12, paddingVertical: 10 },
  lavenderButtonText: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  budgetRow: { paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: "#2A3A35", gap: 8 },
  budgetRowTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  budgetTitle: { flexDirection: "row", alignItems: "center", gap: 8, flex: 1 },
  budgetNumbers: { flexDirection: "row", justifyContent: "space-between", gap: 8 },
  budgetSpent: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  mutedInline: { color: COLORS.muted, fontWeight: "500" },
  budgetLeft: { color: COLORS.mintDark, fontSize: 12, fontWeight: "800" },
  dangerText: { color: COLORS.danger },
  budgetRowBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  primarySmall: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: COLORS.mint, borderRadius: 13, paddingHorizontal: 11, paddingVertical: 9 },
  primarySmallText: { color: COLORS.ink, fontSize: 11, fontWeight: "800" },
  savingsHero: { backgroundColor: COLORS.darkInk, borderRadius: 23, padding: 21, minHeight: 218 },
  owedPill: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 20, padding: 12, borderRadius: 14, backgroundColor: "#2B4742" },
  owedPillLabel: { color: "#A7BDB6", fontSize: 10, fontWeight: "800", letterSpacing: 1.2 },
  owedPillValue: { color: COLORS.mint, fontSize: 13, fontWeight: "900" },
  goalCard: { backgroundColor: COLORS.paper, borderRadius: 19, padding: 17, borderWidth: 1, borderColor: COLORS.border, gap: 11 },
  goalPercent: { color: COLORS.lavenderDark, fontSize: 12, fontWeight: "900" },
  goalAmount: { color: COLORS.ink, fontSize: 19, fontWeight: "900" },
  billRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8 },
  billCopy: { flex: 1 },
  payButton: { borderRadius: 12, backgroundColor: COLORS.darkInk, paddingHorizontal: 12, paddingVertical: 8 },
  payButtonWarm: { backgroundColor: COLORS.coral },
  payButtonText: { color: COLORS.white, fontSize: 11, fontWeight: "800" },
  statusPill: { borderRadius: 12, backgroundColor: COLORS.mint, paddingHorizontal: 10, paddingVertical: 7 },
  statusPillText: { color: COLORS.ink, fontSize: 11, fontWeight: "800" },
  emptyState: { alignItems: "center", justifyContent: "center", paddingVertical: 23, gap: 8 },
  emptyText: { color: COLORS.muted, textAlign: "center", fontSize: 13, lineHeight: 19, maxWidth: 270 },
  fab: { position: "absolute", right: 20, bottom: 24, width: 61, height: 61, borderRadius: 22, backgroundColor: COLORS.mint, alignItems: "center", justifyContent: "center", shadowColor: COLORS.darkInk, shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 6 },
  toast: { position: "absolute", left: 18, right: 92, bottom: 30, minHeight: 44, borderRadius: 15, backgroundColor: COLORS.darkInk, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 13, paddingVertical: 10 },
  toastError: { backgroundColor: COLORS.danger },
  toastText: { color: COLORS.white, fontSize: 12, lineHeight: 17, flex: 1 },
  lockScreen: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 34, backgroundColor: COLORS.cream },
  lockTitle: { color: COLORS.ink, fontSize: 27, fontWeight: "900", marginTop: 7 },
  lockCopy: { color: COLORS.muted, fontSize: 13, marginTop: 7, marginBottom: 20 },
  pinInput: { width: "100%", textAlign: "center", fontSize: 22, letterSpacing: 6, marginBottom: 12 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.66)", justifyContent: "flex-end" },
  modalDismissArea: { flex: 1 },
  modalSheet: { maxHeight: "89%", backgroundColor: COLORS.cream, borderTopLeftRadius: 26, borderTopRightRadius: 26, overflow: "hidden" },
  modalHandle: { alignSelf: "center", width: 42, height: 4, borderRadius: 2, backgroundColor: "#C7C9C1", marginTop: 10 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 19, paddingTop: 14, paddingBottom: 8 },
  modalTitle: { color: COLORS.ink, fontSize: 21, fontWeight: "900" },
  closeButton: { width: 34, height: 34, borderRadius: 17, backgroundColor: COLORS.paper, alignItems: "center", justifyContent: "center" },
  modalContent: { paddingHorizontal: 19, paddingBottom: 30 },
  modalStack: { gap: 13 },
  modalIntro: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginBottom: 2 },
  cloudPanel: { backgroundColor: COLORS.paper, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, padding: 14, gap: 10 },
  e2ePanel: { backgroundColor: COLORS.cream, borderRadius: 15, padding: 12, gap: 10 },
  syncDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.slate },
  syncDotGood: { backgroundColor: COLORS.mintDark },
  syncDotWarn: { backgroundColor: COLORS.coral },
  field: { gap: 6 },
  fieldLabel: { color: COLORS.inkSoft, fontSize: 11, fontWeight: "800", letterSpacing: 0.4 },
  inputWrap: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, flexDirection: "row", alignItems: "center", paddingHorizontal: 13 },
  input: { flex: 1, minHeight: 46, color: COLORS.ink, fontSize: 14, paddingVertical: 10 },
  inputPrefix: { color: COLORS.muted, fontSize: 12, fontWeight: "800", marginRight: 6 },
  textArea: { minHeight: 170, maxHeight: 260, textAlignVertical: "top", borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, padding: 13 },
  choiceScroller: { gap: 8, paddingVertical: 2 },
  choiceChip: { borderRadius: 13, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.border },
  choiceChipActive: { backgroundColor: COLORS.darkInk, borderColor: COLORS.darkInk },
  choiceChipText: { color: COLORS.muted, fontSize: 11, fontWeight: "700" },
  choiceChipTextActive: { color: COLORS.white },
  colorPicker: { flexDirection: "row", gap: 11, alignItems: "center", paddingVertical: 3 },
  colorSwatch: { width: 29, height: 29, borderRadius: 15 },
  colorSwatchSelected: { borderWidth: 3, borderColor: COLORS.paper, shadowColor: COLORS.ink, shadowOpacity: 0.25, shadowRadius: 3, elevation: 3 },
  primaryButton: { minHeight: 49, borderRadius: 15, backgroundColor: COLORS.darkInk, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 2 },
  primaryButtonText: { color: COLORS.white, fontSize: 13, fontWeight: "800" },
  secondaryButton: { minHeight: 45, borderRadius: 15, backgroundColor: "transparent", alignItems: "center", justifyContent: "center" },
  secondaryButtonText: { color: COLORS.muted, fontSize: 13, fontWeight: "800" },
  confirmRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  modalButton: { minHeight: 55, borderRadius: 16, backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.border, flexDirection: "row", alignItems: "center", gap: 11, paddingHorizontal: 14 },
  modalButtonText: { flex: 1, color: COLORS.ink, fontSize: 13, fontWeight: "800" },
  disabledButton: { opacity: 0.4 },
  checkRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 4 },
  checkbox: { width: 23, height: 23, borderRadius: 7, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.paper, alignItems: "center", justifyContent: "center" },
  checkboxActive: { backgroundColor: COLORS.mint, borderColor: COLORS.mintDark },
});
