import { gcm } from "@noble/ciphers/aes.js";
import { pbkdf2 } from "@noble/hashes/pbkdf2.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { secureRandomBytes } from "./random-bytes";

export type EncryptedCloudBackup = {
  version: 1;
  kdf: "PBKDF2-SHA256";
  iterations: number;
  salt: string;
  nonce: string;
  ciphertext: string;
};

const ITERATIONS = 120_000;
const KEY_BYTES = 32;
const SALT_BYTES = 16;
const NONCE_BYTES = 12;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(hex: string): Uint8Array {
  if (!/^[0-9a-f]+$/i.test(hex) || hex.length % 2 !== 0) throw new Error("Encrypted backup is malformed.");
  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < bytes.length; index += 1) bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  return bytes;
}

function textBytes(value: string): Uint8Array {
  return new TextEncoder().encode(value);
}

function textFromBytes(value: Uint8Array): string {
  return new TextDecoder().decode(value);
}

function deriveKey(passphrase: string, salt: Uint8Array, iterations: number): Uint8Array {
  if (passphrase.trim().length < 12) throw new Error("Use a recovery passphrase of at least 12 characters.");
  return pbkdf2(sha256, textBytes(passphrase), salt, { c: iterations, dkLen: KEY_BYTES });
}

export async function encryptCloudBackup(plainText: string, passphrase: string): Promise<string> {
  const salt = await secureRandomBytes(SALT_BYTES);
  const nonce = await secureRandomBytes(NONCE_BYTES);
  const key = deriveKey(passphrase, salt, ITERATIONS);
  const ciphertext = gcm(key, nonce).encrypt(textBytes(plainText));
  const envelope: EncryptedCloudBackup = {
    version: 1,
    kdf: "PBKDF2-SHA256",
    iterations: ITERATIONS,
    salt: bytesToHex(salt),
    nonce: bytesToHex(nonce),
    ciphertext: bytesToHex(ciphertext),
  };
  return JSON.stringify(envelope);
}

export function decryptCloudBackup(serialized: string, passphrase: string): string {
  const envelope = JSON.parse(serialized) as EncryptedCloudBackup;
  if (envelope.version !== 1 || envelope.kdf !== "PBKDF2-SHA256" || envelope.iterations < 100_000) throw new Error("Unsupported encrypted backup version.");
  const salt = hexToBytes(envelope.salt);
  const nonce = hexToBytes(envelope.nonce);
  const key = deriveKey(passphrase, salt, envelope.iterations);
  try {
    return textFromBytes(gcm(key, nonce).decrypt(hexToBytes(envelope.ciphertext)));
  } catch {
    throw new Error("That recovery passphrase could not decrypt this backup.");
  }
}
